/* tslint:disable */
/* eslint-disable */
/**
 * @ variable like @spelldesc123, @spellname456, @versadmg.
 */
export interface AtVariableNode {
    varType: string;
    spellId?: number;
}

/**
 * A fully parsed `SimC` profile.
 */
export interface Profile {
    character: Character;
    equipment: Item[];
    bagItems: Item[];
    weeklyRewards: Item[];
    talents: Talents;
    expansionTalents?: Map<string, string[]>;
    extra: FastMap<string, string>;
    characterInfo?: CharacterInfo;
}

/**
 * A fully parsed spell description.
 */
export interface ParsedSpellDescription {
    nodes: SpellDescriptionNode[];
}

/**
 * A grouping of variable paths within one descriptor domain.
 */
export interface VarPathCategory {
    name: string;
    description: string;
    paths: VarPathInfo[];
}

/**
 * A parsed equipment item.
 */
export interface Item extends GearEntry {
    /**
     * `SimC`\'s named permanent-enchant token (`enchant=`), retained for data-backed resolution.
     */
    enchant?: string;
    suffix?: number;
    gemBonusIds?: number[];
    titanDiscId?: number;
}

/**
 * A single access-control grant (public, Discord guild, or friend list).
 */
export type AccessRule = { type: "public" } | { type: "discord"; target: string } | { type: "friends"; target: string };

/**
 * A single condition branch: predicate + content.
 */
export interface ConditionalBranchNode {
    predicate: ConditionalPredicateNode;
    content: SpellDescriptionNode[];
}

/**
 * A single condition in a predicate.
 */
export type SingleConditionNode = ({ condType: "spellKnown" } & SpellKnownConditionNode) | ({ condType: "aura" } & AuraConditionNode) | ({ condType: "specialization" } & SpecializationConditionNode) | ({ condType: "playerCondition" } & PlayerConditionNode) | ({ condType: "expression" } & ExpressionConditionNode);

/**
 * A single equipped item shared by simulation intents and parsed profiles.
 */
export interface GearEntry {
    slot: GearSlot;
    id: number;
    bonus_ids?: number[];
    enchant_id?: number;
    gem_ids?: number[];
    crafted_stats?: number[];
    crafting_quality?: number;
    drop_level?: number;
    /**
     * Forced final item level, overriding bonus-derived scaling.
     */
    ilevel?: number;
    /**
     * Alternate item whose DBC stat allocations replace this item\'s allocations.
     */
    redirected_base_stats?: number;
}

/**
 * A timeline viewport: the committed pan offset and zoom factor.
 */
export interface TimelineViewport {
    panMs: number;
    zoom: number;
}

/**
 * Additional character info.
 */
export interface CharacterInfo {
    catalystCurrencies: CurrencyEntry[];
    upgradeCurrencies: UpgradeCurrency[];
    slotHighWatermarks: SlotWatermark[];
    upgradeAchievements: number[];
    checksum?: string;
}

/**
 * Aggregated outcome of rotation validation.
 */
export interface ValidationResult {
    valid: boolean;
    errors: ValidationError[];
    warnings: ValidationWarning[];
}

/**
 * An expression that evaluates to a number.
 */
export type ExpressionNode = ({ exprType: "binary" } & BinaryExpressionNode) | ({ exprType: "unary" } & UnaryExpressionNode) | ({ exprType: "functionCall" } & FunctionCallNode) | ({ exprType: "variable" } & VariableNode) | ({ exprType: "number" } & NumberLiteralNode) | ({ exprType: "paren" } & ParenExpressionNode);

/**
 * Any variable reference in a spell description.
 */
export type VariableNode = ({ varKind: "effect" } & EffectVariableNode) | ({ varKind: "spellLevel" } & SpellLevelVariableNode) | ({ varKind: "player" } & PlayerVariableNode) | ({ varKind: "crossSpell" } & CrossSpellReferenceNode) | ({ varKind: "custom" } & CustomVariableNode) | ({ varKind: "at" } & AtVariableNode) | ({ varKind: "enchant" } & EnchantVariableNode) | ({ varKind: "misc" } & MiscVariableNode);

/**
 * Arithmetic operator in a binary expression (add, subtract, multiply, divide).
 */
export type BinaryOperator = "add" | "sub" | "mul" | "div";

/**
 * Binary arithmetic operator for combining numeric condition subtrees.
 */
export type ArithOp = "add" | "sub" | "mul" | "div" | "mod";

/**
 * Binary comparison operator between two numeric condition subtrees.
 */
export type CompareOp = "gt" | "gte" | "lt" | "lte" | "eq" | "ne";

/**
 * Binary expression like $s1 + $SP.
 */
export interface BinaryExpressionNode {
    left: ExpressionNode;
    operator: BinaryOperator;
    right: ExpressionNode;
}

/**
 * Binary selection operator picking the smaller or larger of two subtrees.
 */
export type MinMaxOp = "min" | "max";

/**
 * Candidate item for a slot.
 */
export interface Candidate {
    item: Item;
    source: CandidateSource;
}

/**
 * Candidate items for a single gear slot in a tournament job.
 */
export interface SlotCandidatesConfig {
    slot: string;
    items?: CandidateItemConfig[];
}

/**
 * Cartesian product space.
 */
export interface PermutationSpace {
    slots: SlotCandidates[];
    contestedIndices: number[];
    total: number;
    contestedCount: number;
    totalCandidates: number;
}

/**
 * Character information.
 */
export interface Character {
    name: string;
    level: number;
    race: string;
    class: WowClass;
    spec?: string;
    region?: string;
    server?: string;
    role?: string;
    professions: Profession[];
    zandalariLoa?: string;
    lootSpec?: string;
}

/**
 * Color code like |cFFFFFFFF or |r.
 */
export interface ColorCodeNode {
    code: string;
}

/**
 * Composable condition tree used by authored rotations.
 */
export type Condition = ({ type: "read" } & {} & FieldRead) | { type: "bool"; value: boolean } | { type: "int"; value: number } | { type: "float"; value: number } | { type: "var"; name: string } | { type: "compare"; op: CompareOp; left: Condition; right: Condition } | { type: "and"; operands: Condition[] } | { type: "or"; operands: Condition[] } | { type: "not"; operand: Condition } | { type: "arith"; op: ArithOp; left: Condition; right: Condition } | { type: "unary_math"; op: UnaryMathOp; operand: Condition } | { type: "min_max"; op: MinMaxOp; left: Condition; right: Condition } | { type: "if_then_else"; condition: Condition; then: Condition; otherwise: Condition };

/**
 * Condition referencing a server-side `PlayerCondition` entry.
 */
export interface PlayerConditionNode {
    conditionId: number;
}

/**
 * Condition that checks the player\'s specialization index within their class.
 *
 * `$?c3` on the warrior spell Shield Wall 2565 gates Protection-only text.
 *   `$?c1` on the priest spell Mind Blast 8092 gates Discipline-only text.
 *   The number is therefore `ChrSpecialization.OrderIndex + 1`, never a class ID.
 */
export interface SpecializationConditionNode {
    specIndex: number;
}

/**
 * Condition that checks whether a specific aura is active on the player.
 */
export interface AuraConditionNode {
    auraId: number;
}

/**
 * Condition that checks whether a specific spell is known by the player.
 */
export interface SpellKnownConditionNode {
    spellId: number;
}

/**
 * Condition using a function expression (e.g. `$gt($s1, 5)`).
 */
export interface ExpressionConditionNode {
    funcName: string;
    args: ExpressionNode[];
}

/**
 * Conditional like `$?a123[true text][false text]` or `$?s456[known]?a789[has aura][else]`.
 */
export interface ConditionalNode {
    conditions: ConditionalBranchNode[];
    elseBranch?: SpellDescriptionNode[];
}

/**
 * Cost row for one screening keep percentage.
 */
export interface ScreeningRow {
    keepPct: number;
    survivors: number;
    tournamentCost: number;
    totalCost: number;
    savingsPct: number;
}

/**
 * Cross-spell reference like $123456s1 (spell 123456, effect 1, base points)
 */
export interface CrossSpellReferenceNode {
    spellId: number;
    varType: string;
    effectIndex?: number;
}

/**
 * Currency entry.
 */
export interface CurrencyEntry {
    id: number;
    amount: number;
}

/**
 * Custom variable from spell\'s `description_variables` like `$<healing>`.
 */
export interface CustomVariableNode {
    varName: string;
}

/**
 * Denormalized spell effect data for description-variable resolution (`$s1`, `$t1`, `$x1`, `$a1`, etc.).
 */
export interface SpellEffect {
    index: number;
    effect: number;
    /**
     * Raw `SpellEffect.EffectMechanic`; zero inherits the spell-level mechanic.
     */
    mechanic?: number;
    /**
     * Raw `SpellEffect.EffectAttributes` bitmask.
     */
    effect_attributes?: number;
    aura: number;
    base_points: number;
    period: number;
    chain_targets: number;
    chain_multiplier?: number;
    trigger_spell: number;
    misc_value_0: number;
    misc_value_1: number;
    /**
     * Raw `SpellShapeshiftForm.Flags` for the form referenced by a shapeshift aura.
     */
    shapeshift_form_flags?: number;
    /**
     * Raw `SpellShapeshiftForm.CombatRoundTime` in milliseconds; non-zero when the form imposes its own swing period.
     */
    shapeshift_combat_round_time_ms?: number;
    radius_min: number;
    radius_max: number;
    coefficient: number;
    scaling_class?: number;
    points_per_resource: number;
    variance: number;
    bonus_coefficient: number;
    bonus_coefficient_from_ap: number;
    amplitude: number;
    pvp_multiplier: number;
    effect_class_mask_1?: number;
    effect_class_mask_2?: number;
    effect_class_mask_3?: number;
    effect_class_mask_4?: number;
    /**
     * Raw `SpellEffect.ImplicitTarget[0]` selector (`TargetA`).
     */
    implicit_target_a?: number;
    /**
     * Raw `SpellEffect.ImplicitTarget[1]` selector (`TargetB`).
     */
    implicit_target_b?: number;
}

/**
 * Derived pixel/time geometry for one render of a timeline.
 */
export interface TimelineMetrics {
    trackWidth: number;
    pxPerMs: number;
    visibleMs: number;
    safeZoom: number;
    clampedPanMs: number;
    maxPanMs: number;
    visibleStartMs: number;
    visibleEndMs: number;
    ticks: number[];
}

/**
 * Effect variable like $s1, $m1, $t1, $a1, $o1, $bc1.
 */
export interface EffectVariableNode {
    varType: string;
    effectIndex: number;
}

/**
 * Enchant variable like $ec1, $ecix, $ecd.
 */
export interface EnchantVariableNode {
    varType: string;
}

/**
 * Equipment slot; `repr(u8)` matches `WoW` `inventory_type` IDs.
 */
export type GearSlot = "head" | "neck" | "shoulders" | "shirt" | "chest" | "waist" | "legs" | "feet" | "wrists" | "hands" | "finger1" | "finger2" | "trinket1" | "trinket2" | "back" | "tabard" | "main_hand" | "off_hand";

/**
 * Expression block like ${$s1 * 2 + $SP / 100}.
 */
export interface ExpressionBlockNode {
    expression: ExpressionNode;
    decimalPlaces?: number;
}

/**
 * Flat Midnight item-level scaling config from `ItemScalingConfig` DBC table.
 */
export interface ItemScalingConfigFlat {
    id: number;
    item_offset_curve_id: number;
    item_level: number;
    required_level: number;
    item_squish_era_id: number;
    flags: number;
}

/**
 * Flat Midnight offset-curve entry from `ItemOffsetCurve` DBC table.
 */
export interface ItemOffsetCurveFlat {
    id: number;
    curve_id: number;
    /**
     * DB column is `curve_offset` (`offset` is a SQL reserved word); the Rust field stays `offset`.
     */
    curve_offset: number;
}

/**
 * Flat per-expansion item-squish era from `ItemSquishEra` DBC table.
 */
export interface ItemSquishEraFlat {
    id: number;
    patch: number;
    curve_id: number;
    flags: number;
}

/**
 * Flat stat budgets per item level and quality from `WoW`\'s `RandPropPoints` DBC table.
 */
export interface RandPropPointsFlat {
    id: number;
    damage_replace_stat_f: number;
    damage_secondary_f: number;
    damage_replace_stat: number;
    damage_secondary: number;
    epic_f_0: number;
    epic_f_1: number;
    epic_f_2: number;
    epic_f_3: number;
    epic_f_4: number;
    superior_f_0: number;
    superior_f_1: number;
    superior_f_2: number;
    superior_f_3: number;
    superior_f_4: number;
    good_f_0: number;
    good_f_1: number;
    good_f_2: number;
    good_f_3: number;
    good_f_4: number;
    epic_0: number;
    epic_1: number;
    epic_2: number;
    epic_3: number;
    epic_4: number;
    superior_0: number;
    superior_1: number;
    superior_2: number;
    superior_3: number;
    superior_4: number;
    good_0: number;
    good_1: number;
    good_2: number;
    good_3: number;
    good_4: number;
}

/**
 * Full set of decisions captured during a single `evaluate()` call.
 */
export interface DecisionTrace {
    decisions: Decision[];
}

/**
 * Function call like $gt($s1, 5), $max($s1, $s2), floor($s1 / 100)
 */
export interface FunctionCallNode {
    funcName: string;
    args: ExpressionNode[];
}

/**
 * Gender node like $ghis:her; or $Ghis:her;.
 */
export interface GenderNode {
    male: string;
    female: string;
    capitalized: boolean;
}

/**
 * Hard validation error.
 *
 * The concrete issue representation stays private.
 * Validation can evolve without exposing its internal enum through the Rust API.
 * The serialized tagged shape remains stable for UI consumers.
 */
export type ValidationError = ValidationErrorKind;

/**
 * How `target_if` selects among candidates.
 */
export type TargetIfMode = "min" | "max" | "first";

/**
 * Hunter pet spec.
 */
export type PetType = "Ferocity" | "Tenacity" | "Cunning";

/**
 * Layout + viewport inputs for a timeline (pixels and milliseconds; `zoom`/`pan_ms` are clamped by the math).
 */
export interface TimelineGeometry {
    containerWidth: number;
    gutterWidth: number;
    rightGutter: number;
    durationMs: number;
    panMs: number;
    zoom: number;
    minZoom: number;
    maxZoom: number;
}

/**
 * Leaf node that reads a single field from the runtime buffer.
 */
export interface FieldRead {
    domain: string;
    name: string;
    key?: string;
    on?: AuraOn;
}

/**
 * Metadata about a single variable path.
 */
export interface VarPathInfo {
    name: string;
    description: string;
    valueType: string;
    hasArg: boolean;
    argName: string | undefined;
    example: string;
}

/**
 * Misc variable like $maxcast, $pctD, $W, $W2, $B, $ctrmax1.
 */
export interface MiscVariableNode {
    varName: string;
    id?: number;
}

/**
 * Non-fatal warning.
 */
export type ValidationWarning = { type: "unusedVariable"; name: string } | { type: "unusedList"; name: string } | { type: "constantCondition"; value: boolean; location: string };

/**
 * Number literal like 100 or 3.5.
 */
export interface NumberLiteralNode {
    value: number;
}

/**
 * One 100ms-bucketed resource sample.
 */
export interface ResourceSample {
    timeMs: number;
    resourceName: string;
    current: number;
    max: number;
    gain: number;
    loss: number;
}

/**
 * One aura interval; `end_ms == None` for open-ended intervals.
 */
export interface AuraEvent {
    startMs: number;
    endMs: number | undefined;
    auraSlug: string;
    source: string;
    targetId: number;
    sourceKind: number;
    sourceId: number;
    affectedKind: number;
    affectedId: number;
    pullId: number | undefined;
    groupId: number | undefined;
}

/**
 * One candidate item for a slot.
 */
export interface CandidateItemConfig {
    item_id: number;
    bonus_ids?: number[];
    enchant_id?: number;
    gem_ids?: number[];
}

/**
 * One decision recorded for a single `evaluate()` call.
 */
export interface Decision {
    timeMs: number;
    listId: string;
    firedActionIndex: number | undefined;
    evaluations: ActionEvaluation[];
    nested: Decision[];
}

/**
 * One per-bucket DPS sample for the preview damage-over-time chart.
 */
export interface DpsSample {
    timeMs: number;
    dps: number;
}

/**
 * One slot with its candidates.
 */
export interface SlotCandidates {
    slot: GearSlot;
    candidates: Candidate[];
}

/**
 * Operation used to interpret a field from the dense rotation buffer.
 */
export type EvalKind = "direct" | "timestamp_ready" | "timestamp_remaining" | "timestamp_active" | "timestamp_elapsed" | "timestamp_inactive" | "cooldown_ready" | "cooldown_full_recharge" | "aura_refreshable" | "positive_float" | "resource_deficit" | "resource_pct" | "resource_deficit_pct" | "resource_time_to_max" | "unit_health_pct" | "unit_health_deficit" | "spell_usable";

/**
 * Parenthesized expression node wrapping an inner expression AST.
 */
export interface ParenExpressionNode {
    expression: ExpressionNode;
}

/**
 * Parsed rotation action.
 */
export type Action = { type: "cast"; spell: string; empower_rank?: number; enabled?: boolean; condition?: Condition; target_if?: TargetIf } | { type: "call"; list: string; enabled?: boolean; condition?: Condition } | { type: "run"; list: string; enabled?: boolean; condition?: Condition } | { type: "set_var"; name: string; value: Condition; enabled?: boolean; condition?: Condition } | { type: "modify_var"; name: string; op: VarOp; value: Condition; enabled?: boolean; condition?: Condition } | { type: "wait"; seconds: number; enabled?: boolean; condition?: Condition } | { type: "wait_until"; enabled?: boolean; condition: Condition } | { type: "pool"; enabled?: boolean; extra?: number; condition?: Condition } | { type: "use_trinket"; slot: number; empower_rank?: number; enabled?: boolean; condition?: Condition } | { type: "use_item"; name: string; empower_rank?: number; enabled?: boolean; condition?: Condition };

/**
 * Parsed rotation.
 */
export interface Rotation {
    version: number;
    name: string;
    variables: Record<string, Condition>;
    actions: Action[];
    lists: Record<string, Action[]>;
}

/**
 * Parsed talents section: raw encoded string + decoded loadouts.
 */
export interface Talents {
    encoded: string;
    loadouts: Loadout[];
}

/**
 * Per-action evaluation outcome.
 */
export interface ActionEvaluation {
    listId: string;
    actionIndex: number;
    status: EvaluationStatus;
    rejectionReason?: string;
}

/**
 * Per-spell cast and damage stats.
 */
export interface ActionStat {
    spellId: number;
    targetId: number;
    sourceKind: number;
    sourceId: number;
    pullId: number | undefined;
    groupId: number | undefined;
    casts: number;
    directHits: number;
    crits: number;
    totalDamage: number;
}

/**
 * Per-weapon-slot stats; zeroed means no weapon, so callers must guard against `speed_ms == 0`.
 */
export interface WeaponStats {
    min_damage: number;
    max_damage: number;
    speed_ms: number;
    normalized_speed_s: number;
    item_class: number;
    subclass: number;
    inventory_type: number;
}

/**
 * Percentage values after rating conversion.
 */
export type DerivedStat = "CritChance" | "Haste" | "VersatilityDamage" | "VersatilityDr" | "Mastery";

/**
 * Plain text content.
 */
export interface TextNode {
    value: string;
}

/**
 * Player stat variable like $SP (spell power), $AP (attack power), $MHP (max health)
 */
export interface PlayerVariableNode {
    varName: string;
}

/**
 * Pluralization node like $lstack:stacks; or $Lstack:stacks;.
 */
export interface PluralizationNode {
    singular: string;
    plural: string;
    capitalized: boolean;
}

/**
 * Pre-computed chart overlay data returned across the WASM boundary.
 */
export interface ChartOverlayView {
    mean: number;
    std_dev: number;
    p25: number;
    p50: number;
    p75: number;
    p99: number;
    moving_average: number[];
    trendline_start: number;
    trendline_end: number;
    trendline_r_squared: number;
}

/**
 * Pre-computed cost analysis.
 */
export interface CostAnalysis {
    mainEffectIters: number;
    pairCount: number;
    pairIters: number;
    factorialTotal: number;
    bruteForce: number;
    screening: ScreeningRow[];
}

/**
 * Pre-computed scatter overlay (mean lines + regression segment); when `valid` is false the numeric fields are zeros.
 */
export interface ScatterOverlayView {
    mean_x: number;
    mean_y: number;
    x_min: number;
    x_max: number;
    slope: number;
    intercept: number;
    r_squared: number;
    valid: boolean;
}

/**
 * Predicate for a conditional (OR of conditions)
 */
export interface ConditionalPredicateNode {
    conditions: SingleConditionNode[];
}

/**
 * Primitive value representation stored in a buffer field.
 */
export type FieldType = "bool" | "int" | "float";

/**
 * Profession with skill rank.
 */
export interface Profession {
    name: string;
    rank: number;
}

/**
 * Queryable metadata stored as `meta` jsonb on the `jobs` row.
 */
export interface JobMeta {
    status: string;
    created_at: string;
    completed_at: string;
    pinned: boolean;
    spec_id: number;
    season_id: string;
}

/**
 * Result of a single chunk run: encoded telemetry bytes plus the chunk index.
 */
export interface SimChunkResult {
    bytes: number[];
    chunkIndex: number;
}

/**
 * Saved talent loadout.
 */
export interface Loadout {
    name: string;
    encoded: string;
}

/**
 * Set of access rules controlling who can view a resource.
 */
export interface AccessControl {
    rules: AccessRule[];
}

/**
 * Simulation time in milliseconds.
 */
export type SimTime = number;

/**
 * Single deterministic-seed iteration trace.
 */
export interface IterationTrace {
    durationMs: number;
    seed: number;
    estimatedDps: number;
    totalCasts: number;
    gcdUtilizationPct: number;
    decisions: Decision[];
    resourceSamples: ResourceSample[];
    dpsSamples: DpsSample[];
    auraEvents: AuraEvent[];
    actionStats: ActionStat[];
}

/**
 * Slot high watermark.
 */
export interface SlotWatermark {
    slot: number;
    current: number;
    max: number;
}

/**
 * Spell-level variable like $d (duration), $n (charges), $h (proc chance)
 */
export interface SpellLevelVariableNode {
    varType: string;
    index?: number;
}

/**
 * Stored in `jobs.result`.
 */
export interface SimulationResult {
    meanDps: number;
    minDps: number;
    maxDps: number;
    totalIterations: number;
    chunksCompleted: number;
}

/**
 * Target selection filter.
 */
export interface TargetIf {
    mode: TargetIfMode;
    expr: Condition;
}

/**
 * Top-level node in a spell description.
 */
export type SpellDescriptionNode = ({ type: "text" } & TextNode) | ({ type: "variable" } & VariableNode) | ({ type: "expressionBlock" } & ExpressionBlockNode) | ({ type: "conditional" } & ConditionalNode) | ({ type: "pluralization" } & PluralizationNode) | ({ type: "gender" } & GenderNode) | ({ type: "colorCode" } & ColorCodeNode);

/**
 * Unary arithmetic operator (currently only negation).
 */
export type UnaryOperator = "neg";

/**
 * Unary expression like -$s1.
 */
export interface UnaryExpressionNode {
    operator: UnaryOperator;
    operand: ExpressionNode;
}

/**
 * Unary math function applied to a numeric condition subtree.
 */
export type UnaryMathOp = "floor" | "ceil" | "abs";

/**
 * Upgrade currency; `currency_type` is \'c\' (currency) or \'i\' (item).
 */
export interface UpgradeCurrency {
    currencyType: string;
    id: number;
    amount: number;
}

/**
 * Variable operation.
 */
export type VarOp = "add" | "sub" | "mul" | "div" | "mod" | "max" | "min" | "floor" | "ceil" | "reset";

/**
 * Weapon damage and speed; source for `$mws`/`$mwb`/`$ows`/`$owb`.
 */
export interface WeaponDamage {
    main_min: number;
    main_max: number;
    main_speed: number;
    off_min: number;
    off_max: number;
    off_speed: number;
}

/**
 * Weapon hand for auto-attack queries.
 */
export type Hand = "main" | "off";

/**
 * Where a candidate came from.
 */
export type CandidateSource = "equipped" | "bag" | "weekly";

/**
 * Whether a slot is a singleton or keyed by spell/aura/resource.
 */
export type SlotKind = "singleton" | "keyed";

/**
 * Why an action did or did not fire.
 */
export type EvaluationStatus = "fired" | "executed" | "rejected" | "not_reached" | "disabled";

/**
 * Written to `jobs_chunks.result`.
 */
export interface ChunkResult {
    iterations: number;
    meanDps: number;
    stdDps: number;
    minDps: number;
    maxDps: number;
    spells?: ChunkSpellAggregate[];
    auras?: ChunkAuraAggregate[];
    resources?: ChunkResourceAggregate[];
    cooldowns?: ChunkCooldownAggregate[];
    timeline?: ChunkTimeline;
    metricDescriptors?: ChunkMetricDescriptor[];
    metricValues?: ChunkMetricValue[];
    dpsPercentiles?: DpsPercentiles;
    damageProfile?: ChunkDamageProfile;
}

/**
 * `WoW` class identifiers.
 */
export type WowClass = "death_knight" | "demon_hunter" | "druid" | "evoker" | "hunter" | "mage" | "monk" | "paladin" | "priest" | "rogue" | "shaman" | "warlock" | "warrior";

/**
 *r" A type-safe aura identifier (`WoW` spell ID for auras).
 */
export type AuraIdx = number;

/**
 *r" A type-safe spell identifier (`WoW` spell ID).
 */
export type SpellIdx = number;

/**
 *r" A type-safe unit index: 0 player, 1..N pets, N+1.. enemies.
 */
export type UnitIdx = number;

/**
 *r" Stable identifier for an encounter activation wave.
 */
export type WaveId = number;

/**
 *r" Stable identifier for an encounter enemy group.
 */
export type GroupId = number;

/**
 *r" Stable identifier for an encounter pull.
 */
export type PullId = number;

export interface AppliedBonus {
    bonus_list_id: number;
    /**
     * Bonus type (1=ILEVEL, 2=MOD, 11=SCALING, etc.).
     */
    bonus_type: number;
    description: string;
}

export interface AuraInfo {
    aura_id: number;
    name: string;
    slug: string;
    on: string;
    base_duration_ms: number;
    max_stacks: number;
    pandemic: boolean;
    haste_buff_pct: number;
    damage_mult_pct: number;
    periodic: PeriodicInfo | undefined;
}

export interface AutoAttackInfo {
    spell_id: number;
    swing_ms: number;
    ap_coef: number;
    is_pet: boolean;
}

export interface CdrEffect {
    target_spell_local: number;
    amount_ms: number;
    condition: CdrCondition;
}

export interface CombatRatingsFlat {
    level: number;
    unused_0: number;
    defense_skill: number;
    dodge: number;
    parry: number;
    block: number;
    hit_melee: number;
    hit_ranged: number;
    hit_spell: number;
    crit_melee: number;
    crit_ranged: number;
    crit_spell: number;
    corruption: number;
    corruption_resistance: number;
    speed: number;
    resilience_crit_taken: number;
    resilience_player_damage: number;
    lifesteal: number;
    haste_melee: number;
    haste_ranged: number;
    haste_spell: number;
    avoidance: number;
    sturdiness: number;
    unused_7: number;
    expertise: number;
    armor_penetration: number;
    mastery: number;
    pvp_power: number;
    unused_27: number;
    versatility_damage_done: number;
    versatility_healing_done: number;
    versatility_damage_taken: number;
    unused_12: number;
}

export interface CombatRatingsMultByIlvlFlat {
    item_level: number;
    armor_multiplier: number;
    weapon_multiplier: number;
    trinket_multiplier: number;
    jewelry_multiplier: number;
}

export interface CooldownInfo {
    duration_secs: number;
    max_charges: number;
    recharge_secs: number;
}

export interface CurveFlat {
    id: number;
    type: number;
    flags: number;
}

export interface CurvePointFlat {
    id: number;
    curve_id: number;
    order_index: number;
    pos_0: number;
    pos_1: number;
    pos_pre_squish_0: number;
    pos_pre_squish_1: number;
}

export interface DamageInfo {
    kind: DamageKind;
}

export interface EffectDependency {
    spellId: number;
    effectIndex: number;
    varType: string;
}

export interface FieldDescriptorInfo {
    id: number;
    domain: string;
    name: string;
    field_type: FieldType;
    eval_kind: EvalKind;
    slot_kind: SlotKind;
    description: string;
    key_domain: string | undefined;
}

export interface GemPropertiesFlat {
    id: number;
    enchant_id: number;
    type: number;
}

export interface HeroTalentTree {
    name: string;
    spells: [string, number][];
    auras: [string, number][];
}

export interface HpPerStaFlat {
    level: number;
    health: number;
}

export interface ImplementedSpecInfo {
    spec_id: number;
    class_id: number;
    class_name: string;
    spec_name: string;
    display_name: string;
    slug: string;
    spell_count: number;
    aura_count: number;
    talent_count: number;
}

export interface ItemBonusFlat {
    id: number;
    value_0: number;
    value_1: number;
    value_2: number;
    value_3: number;
    parent_item_bonus_list_id: number;
    type: number;
    order_index: number;
}

export interface ItemClassification {
    class_id: number;
    class_name: string;
    subclass_id: number;
    subclass_name: string;
    inventory_type: number;
    inventory_type_name: string;
    expansion_id: number;
    expansion_name: string;
}

export interface ItemDataFlat {
    id: number;
    name: string;
    description: string;
    file_name: string;
    item_level: number;
    quality: number;
    required_level: number;
    binding: number;
    buy_price: number;
    sell_price: number;
    max_count: number;
    stackable: number;
    speed: number;
    class_id: number;
    subclass_id: number;
    inventory_type: number;
    classification: ItemClassification | undefined;
    stats: ItemStat[];
    effects: ItemEffect[];
    sockets: number[];
    socket_bonus_enchant_id: number;
    flags: number[];
    allowable_class: number;
    allowable_race: number;
    expansion_id: number;
    item_set_id: number;
    set_info: ItemSetInfo | undefined;
    drop_sources: ItemDropSource[];
    dmg_variance: number;
    gem_properties: number;
    modified_crafting_reagent_item_id: number;
}

export interface ItemDropSource {
    instance_id: number;
    instance_name: string;
    encounter_id: number;
    encounter_name: string;
    /**
     * Decoded `Difficulty.ID`s from `DifficultyMask` (bit N = ID N+1); empty Vec means all difficulties (mask -1 or 0).
     */
    difficulty_ids: number[];
}

export interface ItemEffect {
    spell_id: number;
    trigger_type: number;
    charges: number;
    cooldown: number;
    category_cooldown: number;
}

export interface ItemScalingData {
    /**
     * Grouped by `parent_item_bonus_list_id`.
     */
    bonuses: IntMap<number, ItemBonusFlat[]>;
    curves: IntMap<number, CurveFlat>;
    /**
     * Grouped by `curve_id`, sorted by `order_index`.
     */
    curve_points: IntMap<number, CurvePointFlat[]>;
    /**
     * Keyed by item level.
     */
    rand_prop_points: IntMap<number, RandPropPointsFlat>;
    item_scaling_configs: IntMap<number, ItemScalingConfigFlat>;
    item_offset_curves: IntMap<number, ItemOffsetCurveFlat>;
    item_squish_eras: IntMap<number, ItemSquishEraFlat>;
    /**
     * `GameTable` rows keyed by character level.
     */
    combat_ratings?: IntMap<number, CombatRatingsFlat>;
    /**
     * `GameTable` rows keyed by character level.
     */
    hp_per_sta?: IntMap<number, HpPerStaFlat>;
    /**
     * `GameTable` rows keyed by character level.
     */
    spell_scaling?: IntMap<number, SpellScalingFlat>;
    /**
     * `GameTable` rows keyed by item level.
     */
    combat_ratings_mult_by_ilvl?: IntMap<number, CombatRatingsMultByIlvlFlat>;
    stamina_mult_by_ilvl?: IntMap<number, StaminaMultByIlvlFlat>;
    item_socket_cost_per_level?: IntMap<number, ItemSocketCostPerLevelFlat>;
    /**
     * Keyed by `GemProperties.ID` (referenced from `ItemDataFlat::gem_properties`).
     */
    gem_properties?: IntMap<number, GemPropertiesFlat>;
}

export interface ItemSetBonus {
    threshold: number;
    spell_id: number;
    spec_id: number;
}

export interface ItemSetInfo {
    set_id: number;
    set_name: string;
    item_ids: number[];
    bonuses: ItemSetBonus[];
}

export interface ItemStat {
    type: number;
    value: number;
    socket_multiplier?: number;
}

export interface PeriodicInfo {
    tick_ms: number;
    effect: PeriodicEffect;
}

export interface ProgressUpdate {
    completed: number;
    total: number;
    meanDps?: number;
    stdDps?: number;
    throughputSps?: number;
    elapsedMs?: number;
    done: boolean;
}

export interface ResolvedItem {
    id: number;
    name: string;
    file_name: string;
    description: string;
    base_item_level: number;
    item_level: number;
    /**
     * 0..7; a `Quality` bonus may override the base.
     */
    quality: number;
    required_level: number;
    /**
     * 0 = not crafted; else 1..N.
     */
    crafting_quality: number;
    inventory_type: number;
    class_id: number;
    subclass_id: number;
    binding: number;
    speed: number;
    dmg_variance: number;
    classification: ItemClassification | undefined;
    stats: ResolvedStat[];
    sockets: ResolvedSocket[];
    socket_bonus_enchant_id: number;
    effects: ItemEffect[];
    item_set_id: number;
    set_info: ItemSetInfo | undefined;
    weapon: WeaponStats | undefined;
    applied_bonuses: AppliedBonus[];
}

export interface ResolvedPaperdoll {
    spec_id: number;
    /**
     * `ChrSpecialization.OrderIndex`; `$?cN` conditionals name this plus one.
     */
    spec_order_index: number;
    class_id: number;
    level: number;
    is_male: boolean;
    max_health: number;
    role_mult: number;
    stats: ResolvedPaperdollStats;
    weapon: WeaponDamage;
    known_spell_ids: number[];
    active_aura_ids: number[];
}

export interface ResolvedPaperdollStats {
    attack_power: number;
    spell_power: number;
    /**
     * Source for `$pri`.
     */
    primary_stat: number;
    intellect: number;
    crit: number;
    haste: number;
    mastery: number;
    versatility: number;
}

export interface ResolvedSocket {
    /**
     * `SOCKET_COLOR_*` bitmask (from base sockets + Socket bonuses).
     */
    color: number;
}

export interface ResolvedStat {
    stat_type: number;
    stat_name: string;
    /**
     * Final value (`alloc * budget * 0.0001`), rounded.
     */
    value: number;
}

export interface ResourceInfo {
    name: string;
    max: number;
    regen: number;
    starts_at: number;
    type_id: number;
}

export interface SpecIntrospection {
    resource_primary: ResourceInfo;
    resource_secondary: ResourceInfo | undefined;
    spells: SpellInfo[];
    auras: AuraInfo[];
    auto_attacks: AutoAttackInfo[];
    hero_talents: HeroTalentTree[];
}

export interface SpellDescDependencies {
    spellIds: number[];
    effects: EffectDependency[];
    spellValues: SpellValueDependency[];
    playerStats: string[];
    customVars: string[];
    spellKnownChecks: number[];
    auraChecks: number[];
    specializationChecks: number[];
    needsGender: boolean;
    embeddedSpellIds: number[];
}

export interface SpellDescRenderResult {
    fragments: SpellDescFragment[];
    parseErrors: string[];
    warnings: string[];
}

export interface SpellInfo {
    spell_id: number;
    name: string;
    slug: string;
    cast_time_ms: number;
    start_recovery_category: CooldownCategoryId | undefined;
    off_gcd: boolean;
    gcd_ms: number;
    is_pet: boolean;
    breaks_stealth: boolean;
    resource_cost: number;
    resource_gain: number;
    secondary_resource_cost: number;
    secondary_resource_gain: number;
    damage: DamageInfo;
    applies_aura_id: number | undefined;
    cooldown: CooldownInfo | undefined;
    cdr_effects: CdrEffect[];
}

export interface SpellRenderInput {
    self_spell: SpellRenderSpell;
    cross_spells: SpellRenderSpell[];
    paperdoll: ResolvedPaperdoll;
}

export interface SpellRenderSpell {
    id: number;
    description: string;
    description_variables: string;
    cast_time: number;
    recovery_time: number;
    duration: number;
    max_charges: number;
    max_stacks: number;
    range_max_0: number;
    /**
     * Source for `$procrppm`.
     */
    proc_rppm: number;
    /**
     * Source for `$proccooldown`.
     */
    internal_cooldown: number;
    file_name: string;
    name: string;
    effects: SpellEffect[];
}

export interface SpellScalingFlat {
    level: number;
    rogue: number;
    druid: number;
    hunter: number;
    mage: number;
    paladin: number;
    priest: number;
    shaman: number;
    warlock: number;
    warrior: number;
    death_knight: number;
    monk: number;
    demon_hunter: number;
    evoker: number;
    adventurer: number;
    traveler: number;
    item: number;
    consumable: number;
    gem1: number;
    gem2: number;
    gem3: number;
    health: number;
    damage_replace_stat: number;
    damage_secondary: number;
    mana_consumable: number;
}

export interface SpellValueDependency {
    spellId: number;
    varType: string;
}

export type Attribute = "Strength" | "Agility" | "Intellect" | "Stamina";

export type AuraOn = "player" | "target" | "pet";

export type CdrCondition = { type: "Always" } | { type: "ProcChance"; chance: number } | { type: "WhileAuraActive"; aura_local: number } | { type: "ResetWhileAura"; aura_local: number };

export type ClassId = "Warrior" | "Paladin" | "Hunter" | "Rogue" | "Priest" | "DeathKnight" | "Shaman" | "Mage" | "Warlock" | "Monk" | "Druid" | "DemonHunter" | "Evoker";

export type DamageKind = { type: "None" } | { type: "Flat"; amount: number } | { type: "ApCoefficient"; coef: number; is_physical: boolean } | { type: "SpCoefficient"; coef: number; is_physical: boolean } | { type: "Weapon"; multiplier: number; flat_bonus: number; normalized: boolean; is_physical: boolean };

export type DamageSchool = "Physical" | "Holy" | "Fire" | "Nature" | "Frost" | "Shadow" | "Arcane" | "Chaos";

export type EnemyIdx = number;

export type HitResult = "Hit" | "Crit" | "Miss" | "Dodge" | "Parry" | "Glance" | "Block" | "CritBlock";

export type MasteryEffect = "AllDamage" | "PhysicalDamage" | "MagicDamage" | "PetDamage" | { PetAndOwnerDamage: { owner_pct: number } } | "DotDamage" | { ExecuteDamage: { threshold: number } } | { SchoolDamage: DamageSchool } | "Custom";

export type PeriodicEffect = { type: "FlatDamage"; amount: number; is_physical: boolean } | { type: "Damage"; ap_coef: number; is_physical: boolean } | { type: "SpDamage"; sp_coef: number; is_physical: boolean } | { type: "MaxHealthDamage"; percent: number; is_physical: boolean } | { type: "ResourceGain"; amount: number } | { type: "ResourceDrain"; amount: number } | { type: "ApplyAura"; target_aura_local: number } | { type: "ResidualDamage" } | { type: "RemoveStack" } | { type: "Hook" };

export type PetIdx = number;

export type PetKind = "Permanent" | "Guardian" | "Summon";

export type ProcIdx = number;

export type RaceId = "Human" | "Orc" | "Dwarf" | "NightElf" | "Undead" | "Tauren" | "Gnome" | "Troll" | "Goblin" | "BloodElf" | "Draenei" | "Worgen" | "PandarenA" | "PandarenH" | "Nightborne" | "HighmountainTauren" | "VoidElf" | "LightforgedDraenei" | "ZandalariTroll" | "KulTiran" | "DarkIronDwarf" | "Vulpera" | "MagharOrc" | "Mechagnome" | "Dracthyr" | "EarthenA" | "EarthenH";

export type RatingType = "Crit" | "Haste" | "Mastery" | "Versatility" | "Leech" | "Avoidance" | "Speed";

export type ResourceIdx = number;

export type ResourceType = "Mana" | "Rage" | "Focus" | "Energy" | "ComboPoints" | "Runes" | "RunicPower" | "SoulShards" | "LunarPower" | "HolyPower" | "Alternate" | "Maelstrom" | "Chi" | "Insanity" | "ArcaneCharges" | "Fury" | "Pain" | "Essence" | "AlternateQuest" | "AlternateEncounter" | "AlternateMount";

export type SnapshotFlags = Internal;

export type SnapshotIdx = number;

export type SpecId = "Arms" | "Fury" | "ProtWarrior" | "HolyPaladin" | "ProtPaladin" | "Retribution" | "BeastMastery" | "Marksmanship" | "Survival" | "Assassination" | "Outlaw" | "Subtlety" | "Discipline" | "HolyPriest" | "Shadow" | "Blood" | "FrostDK" | "Unholy" | "Elemental" | "Enhancement" | "RestoShaman" | "Arcane" | "Fire" | "FrostMage" | "Affliction" | "Demonology" | "Destruction" | "Brewmaster" | "Mistweaver" | "Windwalker" | "Balance" | "Feral" | "Guardian" | "RestoDruid" | "Havoc" | "Vengeance" | "Devourer" | "Devastation" | "Preservation" | "Augmentation";

export type SpellDescFragment = { kind: "text"; value: string } | { kind: "value"; value: string; raw: number } | { kind: "duration"; value: string; raw_ms: number } | { kind: "colorStart"; color: string } | { kind: "colorEnd" } | { kind: "icon"; spell_id: number; path: string } | { kind: "spellName"; spell_id: number; name: string } | { kind: "embedded"; spell_id: number; fragments: SpellDescFragment[] } | { kind: "unresolved"; token: string } | { kind: "rawToken"; value: string };

export type TargetIdx = number;

export type ValidationErrorKind = { type: "undefinedVariable"; name: string } | { type: "undefinedList"; name: string } | { type: "circularReference"; path: string[] } | { type: "emptyActionList"; list_name: string } | { type: "invalidExpression"; message: string; list_name?: string; action_index?: number; slug?: string } | { type: "duplicateVariable"; name: string } | { type: "duplicateList"; name: string } | { type: "typeMismatch"; name: string; op: string; expected: string; got: string; list_name?: string; action_index?: number } | { type: "unknownField"; domain: string; name: string } | { type: "maxDepthExceeded"; depth: number; max: number } | { type: "actionExpansionLimitExceeded"; actions: number; max: number } | { type: "unsupportedSyntax"; construct: string };


/**
 * WASM-exposed result of analyzing a spell description: dependencies + parse errors.
 */
export class AnalyzeResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    hasErrors(): boolean;
    readonly dependencies: any;
    readonly parseErrors: string[];
}

/**
 * Analyze a spell description and return its data dependencies.
 */
export function analyzeSpellDesc(input: string, self_spell_id: number): AnalyzeResult;

/**
 * Assert the content catalog was populated by the module constructors.
 *
 * A start function cannot return `Result`, so callers check this invariant after instantiation.
 */
export function assertRegistryReady(): void;

/**
 * Short git hash captured at build time.
 */
export function getEngineGitHash(): string;

/**
 * Engine crate version string.
 */
export function getEngineVersion(): string;

/**
 * Descriptor table as a serialized array; filtered by spec's `rotation_field_schema`.
 */
export function getFieldDescriptors(spec_id: number): any;

/**
 * Array of `ImplementedSpecInfo` for every cataloged spec.
 */
export function getImplementedSpecs(): any;

/**
 * Introspection snapshot using empty game data (cheap; values are zero).
 */
export function getSpecIntrospection(spec_id: number): any;

/**
 * Introspection snapshot with real data via the JS resolver.
 */
export function getSpecIntrospectionResolved(spec_id: number, resolver: any): Promise<any>;

/**
 * Rotation field schema for a spec.
 */
export function getSpecRotationFieldSchema(spec_id: number): any;

/**
 * Variable path schema with descriptions.
 */
export function getVarPathSchema(): any;

/**
 * Initialize the WASM runtime: run constructors, link spec registrations, install panic hook.
 */
export function init_wasm_runtime(): void;

/**
 * Parse a rotation JSON string and return the parsed AST.
 */
export function parseRotation(json: string): any;

/**
 * Render a spell description against a resolved character bundle into structured fragments.
 *
 * # Errors
 *
 * Returns [`WasmCommonError`] when the rendered result cannot be serialized for JavaScript.
 */
export function renderSpellDescWithData(input: SpellRenderInput): any;

/**
 * Resolve a character profile (sim config) into a `ResolvedPaperdoll` for live tooltip scaling.
 */
export function resolvePaperdoll(sim_config: string, level: number, is_male: boolean, resolver: any): Promise<any>;

/**
 * One deterministic-seed iteration with decision tracing.
 */
export function runIterationTrace(sim_config: string, rotation_json: string, seed: bigint, resolver: any): Promise<any>;

/**
 * Run a simulation; returns protobuf-encoded `ChunkTelemetry` bytes.
 */
export function runSimulation(sim_config: string, iterations: number, seed: bigint, chunk_index: number, resolver: any): Promise<Uint8Array>;

/**
 * Run a simulation with progress reporting via a JS callback.
 */
export function runSimulationWithProgress(sim_config: string, iterations: number, seed: bigint, chunk_index: number, resolver: any, on_progress: (update: ProgressUpdate) => void): Promise<SimChunkResult>;

/**
 * Tokenize a spell description into fragments for debug display.
 *
 * # Errors
 *
 * Returns [`WasmCommonError`] when the token fragments cannot be serialized for JavaScript.
 */
export function tokenizeSpellDesc(input: string): any;

/**
 * Parse and validate a rotation JSON string.
 */
export function validateRotation(json: string): any;

/**
 * Spec-aware rotation validation (structural + name-resolution).
 */
export function validateRotationForSpec(json: string, spec_id: number): any;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly assertRegistryReady: () => [number, number];
    readonly getEngineGitHash: () => [number, number];
    readonly getEngineVersion: () => [number, number];
    readonly getFieldDescriptors: (a: number) => [number, number, number];
    readonly getImplementedSpecs: () => [number, number, number];
    readonly getSpecIntrospection: (a: number) => [number, number, number];
    readonly getSpecIntrospectionResolved: (a: number, b: any) => any;
    readonly getSpecRotationFieldSchema: (a: number) => [number, number, number];
    readonly getVarPathSchema: () => [number, number, number];
    readonly init_wasm_runtime: () => void;
    readonly parseRotation: (a: number, b: number) => [number, number, number];
    readonly resolvePaperdoll: (a: number, b: number, c: number, d: number, e: any) => any;
    readonly runIterationTrace: (a: number, b: number, c: number, d: number, e: bigint, f: any) => any;
    readonly runSimulation: (a: number, b: number, c: number, d: bigint, e: number, f: any) => any;
    readonly runSimulationWithProgress: (a: number, b: number, c: number, d: bigint, e: number, f: any, g: any) => any;
    readonly validateRotation: (a: number, b: number) => [number, number, number];
    readonly validateRotationForSpec: (a: number, b: number, c: number) => [number, number, number];
    readonly __wbg_analyzeresult_free: (a: number, b: number) => void;
    readonly analyzeSpellDesc: (a: number, b: number, c: number) => number;
    readonly analyzeresult_dependencies: (a: number) => any;
    readonly analyzeresult_hasErrors: (a: number) => number;
    readonly analyzeresult_parseErrors: (a: number) => [number, number];
    readonly renderSpellDescWithData: (a: any) => [number, number, number];
    readonly tokenizeSpellDesc: (a: number, b: number) => [number, number, number];
    readonly wasm_bindgen__convert__closures_____invoke__had4ed51ff9fc41a9: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h0ac11a2c7f38d826: (a: number, b: number, c: any, d: any) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
