/* tslint:disable */
/* eslint-disable */
/**
 * @ variable like @spelldesc123, @spellname456, @versadmg.
 */
export interface AtVariableNode {
    varType: string;
    spellId?: number;
}

/**
 * A fully parsed `SimC` profile.
 */
export interface Profile {
    character: Character;
    equipment: Item[];
    bagItems: Item[];
    weeklyRewards: Item[];
    talents: Talents;
    expansionTalents?: Map<string, string[]>;
    extra: FastMap<string, string>;
    characterInfo?: CharacterInfo;
}

/**
 * A fully parsed spell description.
 */
export interface ParsedSpellDescription {
    nodes: SpellDescriptionNode[];
}

/**
 * A parsed equipment item.
 */
export interface Item extends GearEntry {
    /**
     * `SimC`\'s named permanent-enchant token (`enchant=`), retained for data-backed resolution.
     */
    enchant?: string;
    suffix?: number;
    gemBonusIds?: number[];
    titanDiscId?: number;
}

/**
 * A single access-control grant (public, Discord guild, or friend list).
 */
export type AccessRule = { type: "public" } | { type: "discord"; target: string } | { type: "friends"; target: string };

/**
 * A single condition branch: predicate + content.
 */
export interface ConditionalBranchNode {
    predicate: ConditionalPredicateNode;
    content: SpellDescriptionNode[];
}

/**
 * A single condition in a predicate.
 */
export type SingleConditionNode = ({ condType: "spellKnown" } & SpellKnownConditionNode) | ({ condType: "aura" } & AuraConditionNode) | ({ condType: "specialization" } & SpecializationConditionNode) | ({ condType: "playerCondition" } & PlayerConditionNode) | ({ condType: "expression" } & ExpressionConditionNode);

/**
 * A single equipped item shared by simulation intents and parsed profiles.
 */
export interface GearEntry {
    slot: GearSlot;
    id: number;
    bonus_ids?: number[];
    enchant_id?: number;
    gem_ids?: number[];
    crafted_stats?: number[];
    crafting_quality?: number;
    drop_level?: number;
    /**
     * Forced final item level, overriding bonus-derived scaling.
     */
    ilevel?: number;
    /**
     * Alternate item whose DBC stat allocations replace this item\'s allocations.
     */
    redirected_base_stats?: number;
}

/**
 * A single ranked item within a slot\'s top-N.
 */
export interface SlotItemEntryView {
    item_id: number;
    bonus_id_hash: number;
    best_perm_dps: number;
    best_perm_rank: number;
    ci95_half: number;
    win_rate_pct: number;
    marginal_dps_delta: number;
}

/**
 * A single slot override that distinguishes a permutation from baseline.
 */
export interface SlotDiffView {
    slot_index: number;
    item_id: number;
    bonus_id_hash: number;
}

/**
 * A single timeline marker such as a damage, cast, resource, or proc event.
 */
export interface MarkerView {
    time_ms: number;
    sequence: number;
    kind: string;
    spell_or_aura_id: number;
    target_id: number;
    amount: number;
    is_crit: boolean;
    source: string;
    source_id: number;
    pull_id: number | undefined;
    group_id: number | undefined;
}

/**
 * A timeline viewport: the committed pan offset and zoom factor.
 */
export interface TimelineViewport {
    panMs: number;
    zoom: number;
}

/**
 * Additional character info.
 */
export interface CharacterInfo {
    catalystCurrencies: CurrencyEntry[];
    upgradeCurrencies: UpgradeCurrency[];
    slotHighWatermarks: SlotWatermark[];
    upgradeAchievements: number[];
    checksum?: string;
}

/**
 * An expression that evaluates to a number.
 */
export type ExpressionNode = ({ exprType: "binary" } & BinaryExpressionNode) | ({ exprType: "unary" } & UnaryExpressionNode) | ({ exprType: "functionCall" } & FunctionCallNode) | ({ exprType: "variable" } & VariableNode) | ({ exprType: "number" } & NumberLiteralNode) | ({ exprType: "paren" } & ParenExpressionNode);

/**
 * Any variable reference in a spell description.
 */
export type VariableNode = ({ varKind: "effect" } & EffectVariableNode) | ({ varKind: "spellLevel" } & SpellLevelVariableNode) | ({ varKind: "player" } & PlayerVariableNode) | ({ varKind: "crossSpell" } & CrossSpellReferenceNode) | ({ varKind: "custom" } & CustomVariableNode) | ({ varKind: "at" } & AtVariableNode) | ({ varKind: "enchant" } & EnchantVariableNode) | ({ varKind: "misc" } & MiscVariableNode);

/**
 * Arithmetic operator in a binary expression (add, subtract, multiply, divide).
 */
export type BinaryOperator = "add" | "sub" | "mul" | "div";

/**
 * Binary arithmetic operator for combining numeric condition subtrees.
 */
export type ArithOp = "add" | "sub" | "mul" | "div" | "mod";

/**
 * Binary comparison operator between two numeric condition subtrees.
 */
export type CompareOp = "gt" | "gte" | "lt" | "lte" | "eq" | "ne";

/**
 * Binary expression like $s1 + $SP.
 */
export interface BinaryExpressionNode {
    left: ExpressionNode;
    operator: BinaryOperator;
    right: ExpressionNode;
}

/**
 * Binary selection operator picking the smaller or larger of two subtrees.
 */
export type MinMaxOp = "min" | "max";

/**
 * Bucketed fight timeline with DPS series and event windows.
 */
export interface TimelineView {
    duration_ms: number;
    bucket_ms: number;
    dps_per_bucket: number[];
    bucket_samples: number[];
    markers: MarkerView[];
    aura_windows: AuraWindowView[];
    cooldown_windows: CooldownWindowView[];
    phase_markers: PhaseMarkerView[];
    encounter_events: EncounterEventView[];
}

/**
 * Candidate item for a slot.
 */
export interface Candidate {
    item: Item;
    source: CandidateSource;
}

/**
 * Candidate items for a single gear slot in a tournament job.
 */
export interface SlotCandidatesConfig {
    slot: string;
    items?: CandidateItemConfig[];
}

/**
 * Canonical DPS percentiles (p01 through p99) for distribution summaries.
 */
export interface PercentilesView {
    p01: number;
    p05: number;
    p10: number;
    p25: number;
    p50: number;
    p75: number;
    p90: number;
    p95: number;
    p99: number;
}

/**
 * Cartesian product space.
 */
export interface PermutationSpace {
    slots: SlotCandidates[];
    contestedIndices: number[];
    total: number;
    contestedCount: number;
    totalCandidates: number;
}

/**
 * Character information.
 */
export interface Character {
    name: string;
    level: number;
    race: string;
    class: WowClass;
    spec?: string;
    region?: string;
    server?: string;
    role?: string;
    professions: Profession[];
    zandalariLoa?: string;
    lootSpec?: string;
}

/**
 * Chart-ready view model for a finalized tournament job.
 */
export interface TournamentView {
    stats: TournamentStatsView;
    top_permutations: PermutationSummaryView[];
    slot_rankings: SlotRankingView[];
}

/**
 * Chart-ready view model returned across the WASM boundary.
 */
export interface AnalyticsView {
    core: CoreView;
    distribution: DistributionView | undefined;
    actions: ActionView[];
    auras: AuraView[];
    resources: ResourceView[];
    cooldowns: CooldownView[];
    execution: ExecutionView | undefined;
    damage_profile: DamageProfileView | undefined;
    timeline: TimelineView | undefined;
    dictionary: DictionaryMap;
}

/**
 * Collision-free tagged unit dictionary entry.
 */
export interface UnitMapEntry {
    kind: string;
    id: number;
    label: string;
    target_id: number | undefined;
}

/**
 * Color code like |cFFFFFFFF or |r.
 */
export interface ColorCodeNode {
    code: string;
}

/**
 * Composable condition tree used by authored rotations.
 */
export type Condition = ({ type: "read" } & {} & FieldRead) | { type: "bool"; value: boolean } | { type: "int"; value: number } | { type: "float"; value: number } | { type: "var"; name: string } | { type: "compare"; op: CompareOp; left: Condition; right: Condition } | { type: "and"; operands: Condition[] } | { type: "or"; operands: Condition[] } | { type: "not"; operand: Condition } | { type: "arith"; op: ArithOp; left: Condition; right: Condition } | { type: "unary_math"; op: UnaryMathOp; operand: Condition } | { type: "min_max"; op: MinMaxOp; left: Condition; right: Condition } | { type: "if_then_else"; condition: Condition; then: Condition; otherwise: Condition };

/**
 * Condition referencing a server-side `PlayerCondition` entry.
 */
export interface PlayerConditionNode {
    conditionId: number;
}

/**
 * Condition that checks the player\'s specialization index within their class.
 *
 * `$?c3` on the warrior spell Shield Wall 2565 gates Protection-only text.
 *   `$?c1` on the priest spell Mind Blast 8092 gates Discipline-only text.
 *   The number is therefore `ChrSpecialization.OrderIndex + 1`, never a class ID.
 */
export interface SpecializationConditionNode {
    specIndex: number;
}

/**
 * Condition that checks whether a specific aura is active on the player.
 */
export interface AuraConditionNode {
    auraId: number;
}

/**
 * Condition that checks whether a specific spell is known by the player.
 */
export interface SpellKnownConditionNode {
    spellId: number;
}

/**
 * Condition using a function expression (e.g. `$gt($s1, 5)`).
 */
export interface ExpressionConditionNode {
    funcName: string;
    args: ExpressionNode[];
}

/**
 * Conditional like `$?a123[true text][false text]` or `$?s456[known]?a789[has aura][else]`.
 */
export interface ConditionalNode {
    conditions: ConditionalBranchNode[];
    elseBranch?: SpellDescriptionNode[];
}

/**
 * Cost row for one screening keep percentage.
 */
export interface ScreeningRow {
    keepPct: number;
    survivors: number;
    tournamentCost: number;
    totalCost: number;
    savingsPct: number;
}

/**
 * Cross-spell reference like $123456s1 (spell 123456, effect 1, base points)
 */
export interface CrossSpellReferenceNode {
    spellId: number;
    varType: string;
    effectIndex?: number;
}

/**
 * Currency entry.
 */
export interface CurrencyEntry {
    id: number;
    amount: number;
}

/**
 * Custom variable from spell\'s `description_variables` like `$<healing>`.
 */
export interface CustomVariableNode {
    varName: string;
}

/**
 * DPS distribution summary: histogram plus canonical percentile buckets.
 */
export interface DistributionView {
    sample_count: number;
    histogram: HistogramView;
    percentiles: PercentilesView;
}

/**
 * Damage dealt to a single target, with derived share of total damage.
 */
export interface DamageByTargetView {
    target_id: number;
    total_damage: number;
    damage_pct: number | undefined;
}

/**
 * Damage profile split by direct, periodic, pet, and per-target damage.
 */
export interface DamageProfileView {
    direct_damage: number;
    periodic_damage: number;
    pet_damage: number;
    by_target: DamageByTargetView[];
}

/**
 * Denormalized spell effect data for description-variable resolution (`$s1`, `$t1`, `$x1`, `$a1`, etc.).
 */
export interface SpellEffect {
    index: number;
    effect: number;
    /**
     * Raw `SpellEffect.EffectMechanic`; zero inherits the spell-level mechanic.
     */
    mechanic?: number;
    /**
     * Raw `SpellEffect.EffectAttributes` bitmask.
     */
    effect_attributes?: number;
    aura: number;
    base_points: number;
    period: number;
    chain_targets: number;
    chain_multiplier?: number;
    trigger_spell: number;
    misc_value_0: number;
    misc_value_1: number;
    /**
     * Raw `SpellShapeshiftForm.Flags` for the form referenced by a shapeshift aura.
     */
    shapeshift_form_flags?: number;
    /**
     * Raw `SpellShapeshiftForm.CombatRoundTime` in milliseconds; non-zero when the form imposes its own swing period.
     */
    shapeshift_combat_round_time_ms?: number;
    radius_min: number;
    radius_max: number;
    coefficient: number;
    scaling_class?: number;
    points_per_resource: number;
    variance: number;
    bonus_coefficient: number;
    bonus_coefficient_from_ap: number;
    amplitude: number;
    pvp_multiplier: number;
    effect_class_mask_1?: number;
    effect_class_mask_2?: number;
    effect_class_mask_3?: number;
    effect_class_mask_4?: number;
    /**
     * Raw `SpellEffect.ImplicitTarget[0]` selector (`TargetA`).
     */
    implicit_target_a?: number;
    /**
     * Raw `SpellEffect.ImplicitTarget[1]` selector (`TargetB`).
     */
    implicit_target_b?: number;
}

/**
 * Derived pixel/time geometry for one render of a timeline.
 */
export interface TimelineMetrics {
    trackWidth: number;
    pxPerMs: number;
    visibleMs: number;
    safeZoom: number;
    clampedPanMs: number;
    maxPanMs: number;
    visibleStartMs: number;
    visibleEndMs: number;
    ticks: number[];
}

/**
 * Dictionary entry mapping a target id to a display label.
 */
export interface TargetMapEntry {
    id: number;
    label: string;
    npc_id: number | undefined;
    group_id: number | undefined;
    enemy_tags: string[];
    group_tags: string[];
}

/**
 * Effect variable like $s1, $m1, $t1, $a1, $o1, $bc1.
 */
export interface EffectVariableNode {
    varType: string;
    effectIndex: number;
}

/**
 * Enchant variable like $ec1, $ecix, $ecd.
 */
export interface EnchantVariableNode {
    varType: string;
}

/**
 * Encounter lifecycle observation in its original causal sequence.
 */
export interface EncounterEventView {
    kind: string;
    time_ms: number;
    sequence: number;
    actor: string;
    actor_id: number;
    previous_target_id: number | undefined;
    target_id: number | undefined;
    pull_id: number;
    group_id: number | undefined;
    x: number | undefined;
    y: number | undefined;
    heading: number | undefined;
    layer_id: number | undefined;
}

/**
 * Equal-width DPS histogram with underflow and overflow counters.
 */
export interface HistogramView {
    bin_count: number;
    min_dps: number;
    max_dps: number;
    counts: number[];
    underflow: number;
    overflow: number;
}

/**
 * Equipment slot; `repr(u8)` matches `WoW` `inventory_type` IDs.
 */
export type GearSlot = "head" | "neck" | "shoulders" | "shirt" | "chest" | "waist" | "legs" | "feet" | "wrists" | "hands" | "finger1" | "finger2" | "trinket1" | "trinket2" | "back" | "tabard" | "main_hand" | "off_hand";

/**
 * Execution-time breakdown (active, idle, GCD-locked) with per-bucket action rates.
 */
export interface ExecutionView {
    active_time_ms: number;
    idle_time_ms: number;
    gcd_locked_time_ms: number;
    idle_gcd_count: number;
    avg_queue_lag_ms: number | undefined;
    actions_per_bucket: number[];
    bucket_samples: number[];
}

/**
 * Expression block like ${$s1 * 2 + $SP / 100}.
 */
export interface ExpressionBlockNode {
    expression: ExpressionNode;
    decimalPlaces?: number;
}

/**
 * Flat Midnight item-level scaling config from `ItemScalingConfig` DBC table.
 */
export interface ItemScalingConfigFlat {
    id: number;
    item_offset_curve_id: number;
    item_level: number;
    required_level: number;
    item_squish_era_id: number;
    flags: number;
}

/**
 * Flat Midnight offset-curve entry from `ItemOffsetCurve` DBC table.
 */
export interface ItemOffsetCurveFlat {
    id: number;
    curve_id: number;
    /**
     * DB column is `curve_offset` (`offset` is a SQL reserved word); the Rust field stays `offset`.
     */
    curve_offset: number;
}

/**
 * Flat per-expansion item-squish era from `ItemSquishEra` DBC table.
 */
export interface ItemSquishEraFlat {
    id: number;
    patch: number;
    curve_id: number;
    flags: number;
}

/**
 * Flat stat budgets per item level and quality from `WoW`\'s `RandPropPoints` DBC table.
 */
export interface RandPropPointsFlat {
    id: number;
    damage_replace_stat_f: number;
    damage_secondary_f: number;
    damage_replace_stat: number;
    damage_secondary: number;
    epic_f_0: number;
    epic_f_1: number;
    epic_f_2: number;
    epic_f_3: number;
    epic_f_4: number;
    superior_f_0: number;
    superior_f_1: number;
    superior_f_2: number;
    superior_f_3: number;
    superior_f_4: number;
    good_f_0: number;
    good_f_1: number;
    good_f_2: number;
    good_f_3: number;
    good_f_4: number;
    epic_0: number;
    epic_1: number;
    epic_2: number;
    epic_3: number;
    epic_4: number;
    superior_0: number;
    superior_1: number;
    superior_2: number;
    superior_3: number;
    superior_4: number;
    good_0: number;
    good_1: number;
    good_2: number;
    good_3: number;
    good_4: number;
}

/**
 * Function call like $gt($s1, 5), $max($s1, $s2), floor($s1 / 100)
 */
export interface FunctionCallNode {
    funcName: string;
    args: ExpressionNode[];
}

/**
 * Gender node like $ghis:her; or $Ghis:her;.
 */
export interface GenderNode {
    male: string;
    female: string;
    capitalized: boolean;
}

/**
 * Headline core metrics for a simulation run (iterations, mean DPS, spread).
 */
export interface CoreView {
    iterations: number;
    chunks_completed: number;
    chunks_total: number;
    total_fight_time_ms: number;
    mean_dps: number;
    min_dps: number;
    max_dps: number;
    std_dps: number;
    ci95_half_pct: number;
}

/**
 * Headline tournament stats: winner vs baseline DPS, phases completed, totals.
 */
export interface TournamentStatsView {
    winner_dps: number;
    baseline_dps: number;
    dps_gain: number;
    dps_gain_pct: number | undefined;
    total_permutations: number;
    total_iterations: number;
    phases_completed: number;
}

/**
 * How `target_if` selects among candidates.
 */
export type TargetIfMode = "min" | "max" | "first";

/**
 * Hunter pet spec.
 */
export type PetType = "Ferocity" | "Tenacity" | "Cunning";

/**
 * Layout + viewport inputs for a timeline (pixels and milliseconds; `zoom`/`pan_ms` are clamped by the math).
 */
export interface TimelineGeometry {
    containerWidth: number;
    gutterWidth: number;
    rightGutter: number;
    durationMs: number;
    panMs: number;
    zoom: number;
    minZoom: number;
    maxZoom: number;
}

/**
 * Leaf node that reads a single field from the runtime buffer.
 */
export interface FieldRead {
    domain: string;
    name: string;
    key?: string;
    on?: AuraOn;
}

/**
 * Lookup tables for dictionary-encoded ids in the analytics view.
 */
export interface DictionaryMap {
    spell_ids: number[];
    aura_ids: number[];
    targets: TargetMapEntry[];
    units: UnitMapEntry[];
}

/**
 * Misc variable like $maxcast, $pctD, $W, $W2, $B, $ctrmax1.
 */
export interface MiscVariableNode {
    varName: string;
    id?: number;
}

/**
 * Named phase boundary in the fight timeline.
 */
export interface PhaseMarkerView {
    start_ms: number;
    end_ms: number;
    key: string;
}

/**
 * Number literal like 100 or 3.5.
 */
export interface NumberLiteralNode {
    value: number;
}

/**
 * One candidate item for a slot.
 */
export interface CandidateItemConfig {
    item_id: number;
    bonus_ids?: number[];
    enchant_id?: number;
    gem_ids?: number[];
}

/**
 * One permutation in the ranked top-N output.
 */
export interface PermutationSummaryView {
    rank: number;
    mean_dps: number;
    ci95_half: number;
    dps_delta_from_winner: number;
    diffs: SlotDiffView[];
}

/**
 * One slot with its candidates.
 */
export interface SlotCandidates {
    slot: GearSlot;
    candidates: Candidate[];
}

/**
 * Parenthesized expression node wrapping an inner expression AST.
 */
export interface ParenExpressionNode {
    expression: ExpressionNode;
}

/**
 * Parsed rotation action.
 */
export type Action = { type: "cast"; spell: string; empower_rank?: number; enabled?: boolean; condition?: Condition; target_if?: TargetIf } | { type: "call"; list: string; enabled?: boolean; condition?: Condition } | { type: "run"; list: string; enabled?: boolean; condition?: Condition } | { type: "set_var"; name: string; value: Condition; enabled?: boolean; condition?: Condition } | { type: "modify_var"; name: string; op: VarOp; value: Condition; enabled?: boolean; condition?: Condition } | { type: "wait"; seconds: number; enabled?: boolean; condition?: Condition } | { type: "wait_until"; enabled?: boolean; condition: Condition } | { type: "pool"; enabled?: boolean; extra?: number; condition?: Condition } | { type: "use_trinket"; slot: number; empower_rank?: number; enabled?: boolean; condition?: Condition } | { type: "use_item"; name: string; empower_rank?: number; enabled?: boolean; condition?: Condition };

/**
 * Parsed rotation.
 */
export interface Rotation {
    version: number;
    name: string;
    variables: Record<string, Condition>;
    actions: Action[];
    lists: Record<string, Action[]>;
}

/**
 * Parsed talents section: raw encoded string + decoded loadouts.
 */
export interface Talents {
    encoded: string;
    loadouts: Loadout[];
}

/**
 * Per-aura uptime stats with application and refresh counts.
 */
export interface AuraView {
    aura_id: number;
    target_id: number;
    source: string;
    source_id: number;
    affected: string;
    affected_id: number;
    pull_id: number | undefined;
    group_id: number | undefined;
    uptime_ms: number;
    applications: number;
    refreshes: number;
    stack_seconds: number;
    uptime_pct: number | undefined;
}

/**
 * Per-cooldown efficiency and drift summary.
 */
export interface CooldownView {
    spell_id: number;
    uses: number;
    possible_uses: number;
    drift_sum_ms: number;
    max_drift_ms: number;
    efficiency: number | undefined;
    avg_drift_ms: number | undefined;
}

/**
 * Per-resource flow: gained, spent, wasted, and time spent at cap or starved.
 */
export interface ResourceView {
    resource_type: number;
    gained: number;
    spent: number;
    wasted: number;
    time_at_cap_ms: number;
    starved_time_ms: number;
    cap_pct: number | undefined;
    starved_pct: number | undefined;
}

/**
 * Per-slot ranked candidate items from the tournament.
 */
export interface SlotRankingView {
    slot_index: number;
    items: SlotItemEntryView[];
}

/**
 * Per-spell action summary: casts, hits, damage, resource flow, derived DPS.
 */
export interface ActionView {
    spell_id: number;
    target_id: number;
    source: string;
    source_id: number;
    pull_id: number | undefined;
    group_id: number | undefined;
    casts: number;
    direct_hits: number;
    ticks: number;
    crits: number;
    misses: number;
    dodges: number;
    parries: number;
    total_damage: number;
    execute_time_ms: number;
    resource_spent: number;
    resource_gained: number;
    dps: number | undefined;
    damage_pct: number | undefined;
}

/**
 * Per-weapon-slot stats; zeroed means no weapon, so callers must guard against `speed_ms == 0`.
 */
export interface WeaponStats {
    min_damage: number;
    max_damage: number;
    speed_ms: number;
    normalized_speed_s: number;
    item_class: number;
    subclass: number;
    inventory_type: number;
}

/**
 * Percentage values after rating conversion.
 */
export type DerivedStat = "CritChance" | "Haste" | "VersatilityDamage" | "VersatilityDr" | "Mastery";

/**
 * Plain text content.
 */
export interface TextNode {
    value: string;
}

/**
 * Player stat variable like $SP (spell power), $AP (attack power), $MHP (max health)
 */
export interface PlayerVariableNode {
    varName: string;
}

/**
 * Pluralization node like $lstack:stacks; or $Lstack:stacks;.
 */
export interface PluralizationNode {
    singular: string;
    plural: string;
    capitalized: boolean;
}

/**
 * Pre-computed chart overlay data returned across the WASM boundary.
 */
export interface ChartOverlayView {
    mean: number;
    std_dev: number;
    p25: number;
    p50: number;
    p75: number;
    p99: number;
    moving_average: number[];
    trendline_start: number;
    trendline_end: number;
    trendline_r_squared: number;
}

/**
 * Pre-computed cost analysis.
 */
export interface CostAnalysis {
    mainEffectIters: number;
    pairCount: number;
    pairIters: number;
    factorialTotal: number;
    bruteForce: number;
    screening: ScreeningRow[];
}

/**
 * Pre-computed scatter overlay (mean lines + regression segment); when `valid` is false the numeric fields are zeros.
 */
export interface ScatterOverlayView {
    mean_x: number;
    mean_y: number;
    x_min: number;
    x_max: number;
    slope: number;
    intercept: number;
    r_squared: number;
    valid: boolean;
}

/**
 * Predicate for a conditional (OR of conditions)
 */
export interface ConditionalPredicateNode {
    conditions: SingleConditionNode[];
}

/**
 * Profession with skill rank.
 */
export interface Profession {
    name: string;
    rank: number;
}

/**
 * Queryable metadata stored as `meta` jsonb on the `jobs` row.
 */
export interface JobMeta {
    status: string;
    created_at: string;
    completed_at: string;
    pinned: boolean;
    spec_id: number;
    season_id: string;
}

/**
 * Saved talent loadout.
 */
export interface Loadout {
    name: string;
    encoded: string;
}

/**
 * Set of access rules controlling who can view a resource.
 */
export interface AccessControl {
    rules: AccessRule[];
}

/**
 * Simulation time in milliseconds.
 */
export type SimTime = number;

/**
 * Slot high watermark.
 */
export interface SlotWatermark {
    slot: number;
    current: number;
    max: number;
}

/**
 * Spell-level variable like $d (duration), $n (charges), $h (proc chance)
 */
export interface SpellLevelVariableNode {
    varType: string;
    index?: number;
}

/**
 * Stored in `jobs.result`.
 */
export interface SimulationResult {
    meanDps: number;
    minDps: number;
    maxDps: number;
    totalIterations: number;
    chunksCompleted: number;
}

/**
 * Tagged decoded result envelope: discriminates single and tournament results.
 */
export type JobResultView = { kind: "single"; analytics: AnalyticsView } | { kind: "tournament"; analytics: AnalyticsView | undefined; tournament: TournamentView };

/**
 * Target selection filter.
 */
export interface TargetIf {
    mode: TargetIfMode;
    expr: Condition;
}

/**
 * Time range during which a cooldown-bound ability was active.
 */
export interface CooldownWindowView {
    spell_id: number;
    start_ms: number;
    duration_ms: number;
}

/**
 * Time range during which an aura was active on a target.
 */
export interface AuraWindowView {
    aura_id: number;
    target_id: number;
    start_ms: number;
    end_ms: number;
    source: string;
    source_id: number;
    affected: string;
    affected_id: number;
    pull_id: number | undefined;
    group_id: number | undefined;
}

/**
 * Top-level node in a spell description.
 */
export type SpellDescriptionNode = ({ type: "text" } & TextNode) | ({ type: "variable" } & VariableNode) | ({ type: "expressionBlock" } & ExpressionBlockNode) | ({ type: "conditional" } & ConditionalNode) | ({ type: "pluralization" } & PluralizationNode) | ({ type: "gender" } & GenderNode) | ({ type: "colorCode" } & ColorCodeNode);

/**
 * Unary arithmetic operator (currently only negation).
 */
export type UnaryOperator = "neg";

/**
 * Unary expression like -$s1.
 */
export interface UnaryExpressionNode {
    operator: UnaryOperator;
    operand: ExpressionNode;
}

/**
 * Unary math function applied to a numeric condition subtree.
 */
export type UnaryMathOp = "floor" | "ceil" | "abs";

/**
 * Upgrade currency; `currency_type` is \'c\' (currency) or \'i\' (item).
 */
export interface UpgradeCurrency {
    currencyType: string;
    id: number;
    amount: number;
}

/**
 * Variable operation.
 */
export type VarOp = "add" | "sub" | "mul" | "div" | "mod" | "max" | "min" | "floor" | "ceil" | "reset";

/**
 * Weapon damage and speed; source for `$mws`/`$mwb`/`$ows`/`$owb`.
 */
export interface WeaponDamage {
    main_min: number;
    main_max: number;
    main_speed: number;
    off_min: number;
    off_max: number;
    off_speed: number;
}

/**
 * Weapon hand for auto-attack queries.
 */
export type Hand = "main" | "off";

/**
 * Where a candidate came from.
 */
export type CandidateSource = "equipped" | "bag" | "weekly";

/**
 * Written to `jobs_chunks.result`.
 */
export interface ChunkResult {
    iterations: number;
    meanDps: number;
    stdDps: number;
    minDps: number;
    maxDps: number;
    spells?: ChunkSpellAggregate[];
    auras?: ChunkAuraAggregate[];
    resources?: ChunkResourceAggregate[];
    cooldowns?: ChunkCooldownAggregate[];
    timeline?: ChunkTimeline;
    metricDescriptors?: ChunkMetricDescriptor[];
    metricValues?: ChunkMetricValue[];
    dpsPercentiles?: DpsPercentiles;
    damageProfile?: ChunkDamageProfile;
}

/**
 * `WoW` class identifiers.
 */
export type WowClass = "death_knight" | "demon_hunter" | "druid" | "evoker" | "hunter" | "mage" | "monk" | "paladin" | "priest" | "rogue" | "shaman" | "warlock" | "warrior";

/**
 *r" A type-safe aura identifier (`WoW` spell ID for auras).
 */
export type AuraIdx = number;

/**
 *r" A type-safe spell identifier (`WoW` spell ID).
 */
export type SpellIdx = number;

/**
 *r" A type-safe unit index: 0 player, 1..N pets, N+1.. enemies.
 */
export type UnitIdx = number;

/**
 *r" Stable identifier for an encounter activation wave.
 */
export type WaveId = number;

/**
 *r" Stable identifier for an encounter enemy group.
 */
export type GroupId = number;

/**
 *r" Stable identifier for an encounter pull.
 */
export type PullId = number;

export interface AppliedBonus {
    bonus_list_id: number;
    /**
     * Bonus type (1=ILEVEL, 2=MOD, 11=SCALING, etc.).
     */
    bonus_type: number;
    description: string;
}

export interface AuraInfo {
    aura_id: number;
    name: string;
    slug: string;
    on: string;
    base_duration_ms: number;
    max_stacks: number;
    pandemic: boolean;
    haste_buff_pct: number;
    damage_mult_pct: number;
    periodic: PeriodicInfo | undefined;
}

export interface AutoAttackInfo {
    spell_id: number;
    swing_ms: number;
    ap_coef: number;
    is_pet: boolean;
}

export interface CdrEffect {
    target_spell_local: number;
    amount_ms: number;
    condition: CdrCondition;
}

export interface CombatRatingsFlat {
    level: number;
    unused_0: number;
    defense_skill: number;
    dodge: number;
    parry: number;
    block: number;
    hit_melee: number;
    hit_ranged: number;
    hit_spell: number;
    crit_melee: number;
    crit_ranged: number;
    crit_spell: number;
    corruption: number;
    corruption_resistance: number;
    speed: number;
    resilience_crit_taken: number;
    resilience_player_damage: number;
    lifesteal: number;
    haste_melee: number;
    haste_ranged: number;
    haste_spell: number;
    avoidance: number;
    sturdiness: number;
    unused_7: number;
    expertise: number;
    armor_penetration: number;
    mastery: number;
    pvp_power: number;
    unused_27: number;
    versatility_damage_done: number;
    versatility_healing_done: number;
    versatility_damage_taken: number;
    unused_12: number;
}

export interface CombatRatingsMultByIlvlFlat {
    item_level: number;
    armor_multiplier: number;
    weapon_multiplier: number;
    trinket_multiplier: number;
    jewelry_multiplier: number;
}

export interface CooldownInfo {
    duration_secs: number;
    max_charges: number;
    recharge_secs: number;
}

export interface CurveFlat {
    id: number;
    type: number;
    flags: number;
}

export interface CurvePointFlat {
    id: number;
    curve_id: number;
    order_index: number;
    pos_0: number;
    pos_1: number;
    pos_pre_squish_0: number;
    pos_pre_squish_1: number;
}

export interface DamageInfo {
    kind: DamageKind;
}

export interface EffectDependency {
    spellId: number;
    effectIndex: number;
    varType: string;
}

export interface GemPropertiesFlat {
    id: number;
    enchant_id: number;
    type: number;
}

export interface HeroTalentTree {
    name: string;
    spells: [string, number][];
    auras: [string, number][];
}

export interface HpPerStaFlat {
    level: number;
    health: number;
}

export interface ImplementedSpecInfo {
    spec_id: number;
    class_id: number;
    class_name: string;
    spec_name: string;
    display_name: string;
    slug: string;
    spell_count: number;
    aura_count: number;
    talent_count: number;
}

export interface ItemBonusFlat {
    id: number;
    value_0: number;
    value_1: number;
    value_2: number;
    value_3: number;
    parent_item_bonus_list_id: number;
    type: number;
    order_index: number;
}

export interface ItemClassification {
    class_id: number;
    class_name: string;
    subclass_id: number;
    subclass_name: string;
    inventory_type: number;
    inventory_type_name: string;
    expansion_id: number;
    expansion_name: string;
}

export interface ItemDataFlat {
    id: number;
    name: string;
    description: string;
    file_name: string;
    item_level: number;
    quality: number;
    required_level: number;
    binding: number;
    buy_price: number;
    sell_price: number;
    max_count: number;
    stackable: number;
    speed: number;
    class_id: number;
    subclass_id: number;
    inventory_type: number;
    classification: ItemClassification | undefined;
    stats: ItemStat[];
    effects: ItemEffect[];
    sockets: number[];
    socket_bonus_enchant_id: number;
    flags: number[];
    allowable_class: number;
    allowable_race: number;
    expansion_id: number;
    item_set_id: number;
    set_info: ItemSetInfo | undefined;
    drop_sources: ItemDropSource[];
    dmg_variance: number;
    gem_properties: number;
    modified_crafting_reagent_item_id: number;
}

export interface ItemDropSource {
    instance_id: number;
    instance_name: string;
    encounter_id: number;
    encounter_name: string;
    /**
     * Decoded `Difficulty.ID`s from `DifficultyMask` (bit N = ID N+1); empty Vec means all difficulties (mask -1 or 0).
     */
    difficulty_ids: number[];
}

export interface ItemEffect {
    spell_id: number;
    trigger_type: number;
    charges: number;
    cooldown: number;
    category_cooldown: number;
}

export interface ItemScalingData {
    /**
     * Grouped by `parent_item_bonus_list_id`.
     */
    bonuses: IntMap<number, ItemBonusFlat[]>;
    curves: IntMap<number, CurveFlat>;
    /**
     * Grouped by `curve_id`, sorted by `order_index`.
     */
    curve_points: IntMap<number, CurvePointFlat[]>;
    /**
     * Keyed by item level.
     */
    rand_prop_points: IntMap<number, RandPropPointsFlat>;
    item_scaling_configs: IntMap<number, ItemScalingConfigFlat>;
    item_offset_curves: IntMap<number, ItemOffsetCurveFlat>;
    item_squish_eras: IntMap<number, ItemSquishEraFlat>;
    /**
     * `GameTable` rows keyed by character level.
     */
    combat_ratings?: IntMap<number, CombatRatingsFlat>;
    /**
     * `GameTable` rows keyed by character level.
     */
    hp_per_sta?: IntMap<number, HpPerStaFlat>;
    /**
     * `GameTable` rows keyed by character level.
     */
    spell_scaling?: IntMap<number, SpellScalingFlat>;
    /**
     * `GameTable` rows keyed by item level.
     */
    combat_ratings_mult_by_ilvl?: IntMap<number, CombatRatingsMultByIlvlFlat>;
    stamina_mult_by_ilvl?: IntMap<number, StaminaMultByIlvlFlat>;
    item_socket_cost_per_level?: IntMap<number, ItemSocketCostPerLevelFlat>;
    /**
     * Keyed by `GemProperties.ID` (referenced from `ItemDataFlat::gem_properties`).
     */
    gem_properties?: IntMap<number, GemPropertiesFlat>;
}

export interface ItemSetBonus {
    threshold: number;
    spell_id: number;
    spec_id: number;
}

export interface ItemSetInfo {
    set_id: number;
    set_name: string;
    item_ids: number[];
    bonuses: ItemSetBonus[];
}

export interface ItemStat {
    type: number;
    value: number;
    socket_multiplier?: number;
}

export interface ParcelConfigDto {
    prefix: string;
    contentTypes?: string[];
    defaultContentType?: string | undefined;
    maxEncodedLen?: number | undefined;
    maxDecodedBody?: number | undefined;
    maxPayloadBytes?: number | undefined;
}

export interface ParcelDecodeMetaDto {
    prefix: string;
    contentType: string;
    checksum: string;
    encodedBytes: number;
    decodedBodyBytes: number;
    payloadBytes: number;
}

export interface ParcelDecodedDto {
    payload: number[];
    meta: ParcelDecodeMetaDto;
}

export interface ParcelLimitsDto {
    maxEncodedLen: number;
    maxDecodedBody: number;
    maxPayloadBytes: number;
}

export interface PeriodicInfo {
    tick_ms: number;
    effect: PeriodicEffect;
}

export interface ResolvedItem {
    id: number;
    name: string;
    file_name: string;
    description: string;
    base_item_level: number;
    item_level: number;
    /**
     * 0..7; a `Quality` bonus may override the base.
     */
    quality: number;
    required_level: number;
    /**
     * 0 = not crafted; else 1..N.
     */
    crafting_quality: number;
    inventory_type: number;
    class_id: number;
    subclass_id: number;
    binding: number;
    speed: number;
    dmg_variance: number;
    classification: ItemClassification | undefined;
    stats: ResolvedStat[];
    sockets: ResolvedSocket[];
    socket_bonus_enchant_id: number;
    effects: ItemEffect[];
    item_set_id: number;
    set_info: ItemSetInfo | undefined;
    weapon: WeaponStats | undefined;
    applied_bonuses: AppliedBonus[];
}

export interface ResolvedPaperdoll {
    spec_id: number;
    /**
     * `ChrSpecialization.OrderIndex`; `$?cN` conditionals name this plus one.
     */
    spec_order_index: number;
    class_id: number;
    level: number;
    is_male: boolean;
    max_health: number;
    role_mult: number;
    stats: ResolvedPaperdollStats;
    weapon: WeaponDamage;
    known_spell_ids: number[];
    active_aura_ids: number[];
}

export interface ResolvedPaperdollStats {
    attack_power: number;
    spell_power: number;
    /**
     * Source for `$pri`.
     */
    primary_stat: number;
    intellect: number;
    crit: number;
    haste: number;
    mastery: number;
    versatility: number;
}

export interface ResolvedSocket {
    /**
     * `SOCKET_COLOR_*` bitmask (from base sockets + Socket bonuses).
     */
    color: number;
}

export interface ResolvedStat {
    stat_type: number;
    stat_name: string;
    /**
     * Final value (`alloc * budget * 0.0001`), rounded.
     */
    value: number;
}

export interface ResourceInfo {
    name: string;
    max: number;
    regen: number;
    starts_at: number;
    type_id: number;
}

export interface ResultExportDto {
    v: number;
    kind: ExportKindDto;
    spec: string;
    jobId?: string | undefined;
    generatedAtMs: number;
    baselineDps: number;
    winnerDps: number;
    items: ResultItemDto[];
    note?: string | undefined;
}

export interface ResultItemDto {
    slot: string;
    itemId: number;
    bonusIds?: number[];
    gemIds?: number[];
    gemBonusIds?: number[];
    enchantId?: number | undefined;
    craftedStats?: number[];
    craftingQuality?: number | undefined;
    dropLevel?: number | undefined;
    suffix?: number | undefined;
    itemLevel?: number | undefined;
    meanDps: number;
    dpsDeltaVsBaseline: number;
    ci95Half?: number | undefined;
    rank: number;
    winRate?: number | undefined;
    sourceLabel?: string | undefined;
}

export interface SpecIntrospection {
    resource_primary: ResourceInfo;
    resource_secondary: ResourceInfo | undefined;
    spells: SpellInfo[];
    auras: AuraInfo[];
    auto_attacks: AutoAttackInfo[];
    hero_talents: HeroTalentTree[];
}

export interface SpellDescDependencies {
    spellIds: number[];
    effects: EffectDependency[];
    spellValues: SpellValueDependency[];
    playerStats: string[];
    customVars: string[];
    spellKnownChecks: number[];
    auraChecks: number[];
    specializationChecks: number[];
    needsGender: boolean;
    embeddedSpellIds: number[];
}

export interface SpellDescRenderResult {
    fragments: SpellDescFragment[];
    parseErrors: string[];
    warnings: string[];
}

export interface SpellInfo {
    spell_id: number;
    name: string;
    slug: string;
    cast_time_ms: number;
    start_recovery_category: CooldownCategoryId | undefined;
    off_gcd: boolean;
    gcd_ms: number;
    is_pet: boolean;
    breaks_stealth: boolean;
    resource_cost: number;
    resource_gain: number;
    secondary_resource_cost: number;
    secondary_resource_gain: number;
    damage: DamageInfo;
    applies_aura_id: number | undefined;
    cooldown: CooldownInfo | undefined;
    cdr_effects: CdrEffect[];
}

export interface SpellRenderInput {
    self_spell: SpellRenderSpell;
    cross_spells: SpellRenderSpell[];
    paperdoll: ResolvedPaperdoll;
}

export interface SpellRenderSpell {
    id: number;
    description: string;
    description_variables: string;
    cast_time: number;
    recovery_time: number;
    duration: number;
    max_charges: number;
    max_stacks: number;
    range_max_0: number;
    /**
     * Source for `$procrppm`.
     */
    proc_rppm: number;
    /**
     * Source for `$proccooldown`.
     */
    internal_cooldown: number;
    file_name: string;
    name: string;
    effects: SpellEffect[];
}

export interface SpellScalingFlat {
    level: number;
    rogue: number;
    druid: number;
    hunter: number;
    mage: number;
    paladin: number;
    priest: number;
    shaman: number;
    warlock: number;
    warrior: number;
    death_knight: number;
    monk: number;
    demon_hunter: number;
    evoker: number;
    adventurer: number;
    traveler: number;
    item: number;
    consumable: number;
    gem1: number;
    gem2: number;
    gem3: number;
    health: number;
    damage_replace_stat: number;
    damage_secondary: number;
    mana_consumable: number;
}

export interface SpellValueDependency {
    spellId: number;
    varType: string;
}

export type Attribute = "Strength" | "Agility" | "Intellect" | "Stamina";

export type AuraOn = "player" | "target" | "pet";

export type CdrCondition = { type: "Always" } | { type: "ProcChance"; chance: number } | { type: "WhileAuraActive"; aura_local: number } | { type: "ResetWhileAura"; aura_local: number };

export type ClassId = "Warrior" | "Paladin" | "Hunter" | "Rogue" | "Priest" | "DeathKnight" | "Shaman" | "Mage" | "Warlock" | "Monk" | "Druid" | "DemonHunter" | "Evoker";

export type DamageKind = { type: "None" } | { type: "Flat"; amount: number } | { type: "ApCoefficient"; coef: number; is_physical: boolean } | { type: "SpCoefficient"; coef: number; is_physical: boolean } | { type: "Weapon"; multiplier: number; flat_bonus: number; normalized: boolean; is_physical: boolean };

export type DamageSchool = "Physical" | "Holy" | "Fire" | "Nature" | "Frost" | "Shadow" | "Arcane" | "Chaos";

export type EnemyIdx = number;

export type ExportKindDto = "bib" | "drops";

export type HitResult = "Hit" | "Crit" | "Miss" | "Dodge" | "Parry" | "Glance" | "Block" | "CritBlock";

export type MasteryEffect = "AllDamage" | "PhysicalDamage" | "MagicDamage" | "PetDamage" | { PetAndOwnerDamage: { owner_pct: number } } | "DotDamage" | { ExecuteDamage: { threshold: number } } | { SchoolDamage: DamageSchool } | "Custom";

export type PeriodicEffect = { type: "FlatDamage"; amount: number; is_physical: boolean } | { type: "Damage"; ap_coef: number; is_physical: boolean } | { type: "SpDamage"; sp_coef: number; is_physical: boolean } | { type: "MaxHealthDamage"; percent: number; is_physical: boolean } | { type: "ResourceGain"; amount: number } | { type: "ResourceDrain"; amount: number } | { type: "ApplyAura"; target_aura_local: number } | { type: "ResidualDamage" } | { type: "RemoveStack" } | { type: "Hook" };

export type PetIdx = number;

export type PetKind = "Permanent" | "Guardian" | "Summon";

export type ProcIdx = number;

export type RaceId = "Human" | "Orc" | "Dwarf" | "NightElf" | "Undead" | "Tauren" | "Gnome" | "Troll" | "Goblin" | "BloodElf" | "Draenei" | "Worgen" | "PandarenA" | "PandarenH" | "Nightborne" | "HighmountainTauren" | "VoidElf" | "LightforgedDraenei" | "ZandalariTroll" | "KulTiran" | "DarkIronDwarf" | "Vulpera" | "MagharOrc" | "Mechagnome" | "Dracthyr" | "EarthenA" | "EarthenH";

export type RatingType = "Crit" | "Haste" | "Mastery" | "Versatility" | "Leech" | "Avoidance" | "Speed";

export type ResourceIdx = number;

export type ResourceType = "Mana" | "Rage" | "Focus" | "Energy" | "ComboPoints" | "Runes" | "RunicPower" | "SoulShards" | "LunarPower" | "HolyPower" | "Alternate" | "Maelstrom" | "Chi" | "Insanity" | "ArcaneCharges" | "Fury" | "Pain" | "Essence" | "AlternateQuest" | "AlternateEncounter" | "AlternateMount";

export type SnapshotFlags = Internal;

export type SnapshotIdx = number;

export type SpecId = "Arms" | "Fury" | "ProtWarrior" | "HolyPaladin" | "ProtPaladin" | "Retribution" | "BeastMastery" | "Marksmanship" | "Survival" | "Assassination" | "Outlaw" | "Subtlety" | "Discipline" | "HolyPriest" | "Shadow" | "Blood" | "FrostDK" | "Unholy" | "Elemental" | "Enhancement" | "RestoShaman" | "Arcane" | "Fire" | "FrostMage" | "Affliction" | "Demonology" | "Destruction" | "Brewmaster" | "Mistweaver" | "Windwalker" | "Balance" | "Feral" | "Guardian" | "RestoDruid" | "Havoc" | "Vengeance" | "Devourer" | "Devastation" | "Preservation" | "Augmentation";

export type SpellDescFragment = { kind: "text"; value: string } | { kind: "value"; value: string; raw: number } | { kind: "duration"; value: string; raw_ms: number } | { kind: "colorStart"; color: string } | { kind: "colorEnd" } | { kind: "icon"; spell_id: number; path: string } | { kind: "spellName"; spell_id: number; name: string } | { kind: "embedded"; spell_id: number; fragments: SpellDescFragment[] } | { kind: "unresolved"; token: string } | { kind: "rawToken"; value: string };

export type TargetIdx = number;


/**
 * WASM-exposed result of analyzing a spell description: dependencies + parse errors.
 */
export class AnalyzeResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    hasErrors(): boolean;
    readonly dependencies: any;
    readonly parseErrors: string[];
}

export class MarkdownDoc {
    free(): void;
    [Symbol.dispose](): void;
    blank(): void;
    build(): string;
    bullet(text: string): void;
    codeBlock(language: string, content: string): void;
    def(term: string, desc: string): void;
    defDetail(term: string, detail: string, desc: string): void;
    h1(text: string): void;
    h2(text: string): void;
    h3(text: string): void;
    heading(level: number, text: string): void;
    kvBullet(key: string, value: string): void;
    line(text: string): void;
    constructor();
    raw(text: string): void;
}

export class MarkdownTable {
    free(): void;
    [Symbol.dispose](): void;
    buildMarkdown(): string;
    buildPlain(): string;
    headers(headers: string[]): void;
    constructor();
    row(values: string[]): void;
}

/**
 * Analyze a spell description and return its data dependencies.
 */
export function analyzeSpellDesc(input: string, self_spell_id: number): AnalyzeResult;

export function buildPermutationSpace(profile: any): any;

/**
 * Build a TOML sentinel config string from a JS object.
 */
export function buildSentinelConfig(input: any): string;

export function buildSignMessage(timestamp: bigint, method: string, host: string, path: string, body: string): string;

export function buildSignMessageBytes(timestamp: bigint, method: string, host: string, path: string, body: Uint8Array): string;

/**
 * Build a TOML sim config string from a JS object.
 */
export function buildSimConfig(input: any): string;

export function buildSpaceForSelection(profile: any, selections: any): any;

export function computeChartOverlay(y_values: Float64Array): ChartOverlayView;

export function computeCostAnalysis(space: any): any;

export function computeScatterOverlay(xs: Float64Array, ys: Float64Array): ScatterOverlayView;

export function computeTimelineMetrics(geometry: TimelineGeometry): TimelineMetrics;

/**
 * Decode `ResultViewV1` + `TimelineViewV1` and derive `AnalyticsView`.
 */
export function decodeAndDerive(result_hex: string, timeline_hex: string): AnalyticsView;

/**
 * Decode the `JobResult` + `JobTimeline` envelope and return a tagged view.
 */
export function decodeJobResult(result_hex: string, timeline_hex: string): JobResultView;

export function decodeLoadout(loadout: string): any;

/**
 * Encode a minimal loadout string for a spec with no talent selections.
 */
export function encodeMinimalLoadout(spec_id: number): string;

export function extractSpecIdFromLoadout(loadout: string): number;

/**
 * Generate a new node keypair. Returns `{ privateKey, publicKey }`.
 */
export function generateNodeKeypair(): any;

/**
 * Generate permutation rows (item IDs per contested slot) for indices 0..limit.
 */
export function generatePermutationRows(space: any, limit: number): any;

export function panTimelineBy(geometry: TimelineGeometry, start_pan_ms: number, delta_px: number): TimelineViewport;

export function parcelDecode(config: ParcelConfigDto, encoded: string): ParcelDecodedDto;

export function parcelDecodeResultExport(encoded: string): ResultExportDto;

export function parcelDefaultLimits(): ParcelLimitsDto;

/**
 * Encode raw payload bytes into a parcel envelope (`contentType` null uses the codec default).
 */
export function parcelEncode(config: ParcelConfigDto, content_type: string | null | undefined, payload: Uint8Array): string;

export function parcelEncodeResultExport(_export: ResultExportDto): string;

/**
 * Render the inspect summary; a malformed envelope yields a string starting with `LibParcel inspect: ERR_...`.
 */
export function parcelInspect(config: ParcelConfigDto, encoded: string): string;

export function parcelResultExportPrefix(): string;

/**
 * Parse and validate engine `getImplementedSpecs()` payload.
 */
export function parseImplementedSpecs(input: any): ImplementedSpecInfo[];

export function parseJobMeta(json: string): JobMeta;

export function parseSimc(input: string): Profile;

export function parseSpellDesc(input: string): ParsedSpellDescription;

export function renderGlobalString(input: string): string;

/**
 * Render a spell description against a resolved character bundle into structured fragments.
 *
 * # Errors
 *
 * Returns [`WasmCommonError`] when the rendered result cannot be serialized for JavaScript.
 */
export function renderSpellDescWithData(input: SpellRenderInput): any;

export function resolveItem(base_item: ItemDataFlat, bonus_ids: any, scaling_data: ItemScalingData, player_level?: number | null, drop_level?: number | null): ResolvedItem;

export function sha256Hex(data: string): string;

/**
 * Sign a message with a base64-encoded private key. Returns signature as base64.
 */
export function signMessage(private_key_base64: string, message: string): string;

/**
 * Tokenize a spell description into fragments for debug display.
 *
 * # Errors
 *
 * Returns [`WasmCommonError`] when the token fragments cannot be serialized for JavaScript.
 */
export function tokenizeSpellDesc(input: string): any;

export function tournamentPayload(space: any): any;

export function verifySignature(public_key_base64: string, message: string, signature_base64: string): boolean;

/**
 * Compute the new viewport after a cursor-anchored zoom step (`local_x` is pixels from the track's left edge).
 */
export function zoomTimelineAt(geometry: TimelineGeometry, local_x: number, zoom_in: boolean, zoom_factor: number): TimelineViewport;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_markdowndoc_free: (a: number, b: number) => void;
    readonly __wbg_markdowntable_free: (a: number, b: number) => void;
    readonly buildPermutationSpace: (a: number, b: number) => void;
    readonly buildSentinelConfig: (a: number, b: number) => void;
    readonly buildSignMessage: (a: number, b: bigint, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => void;
    readonly buildSignMessageBytes: (a: number, b: bigint, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => void;
    readonly buildSimConfig: (a: number, b: number) => void;
    readonly buildSpaceForSelection: (a: number, b: number, c: number) => void;
    readonly computeChartOverlay: (a: number, b: number) => number;
    readonly computeCostAnalysis: (a: number, b: number) => void;
    readonly computeScatterOverlay: (a: number, b: number, c: number, d: number) => number;
    readonly computeTimelineMetrics: (a: number) => number;
    readonly decodeAndDerive: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly decodeJobResult: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly decodeLoadout: (a: number, b: number, c: number) => void;
    readonly encodeMinimalLoadout: (a: number, b: number) => void;
    readonly extractSpecIdFromLoadout: (a: number, b: number, c: number) => void;
    readonly generateNodeKeypair: (a: number) => void;
    readonly generatePermutationRows: (a: number, b: number, c: number) => void;
    readonly markdowndoc_blank: (a: number) => void;
    readonly markdowndoc_build: (a: number, b: number) => void;
    readonly markdowndoc_bullet: (a: number, b: number, c: number) => void;
    readonly markdowndoc_codeBlock: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly markdowndoc_def: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly markdowndoc_defDetail: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly markdowndoc_h1: (a: number, b: number, c: number) => void;
    readonly markdowndoc_h2: (a: number, b: number, c: number) => void;
    readonly markdowndoc_h3: (a: number, b: number, c: number) => void;
    readonly markdowndoc_heading: (a: number, b: number, c: number, d: number) => void;
    readonly markdowndoc_kvBullet: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly markdowndoc_line: (a: number, b: number, c: number) => void;
    readonly markdowndoc_new: () => number;
    readonly markdowndoc_raw: (a: number, b: number, c: number) => void;
    readonly markdowntable_buildMarkdown: (a: number, b: number) => void;
    readonly markdowntable_buildPlain: (a: number, b: number) => void;
    readonly markdowntable_headers: (a: number, b: number, c: number) => void;
    readonly markdowntable_new: () => number;
    readonly markdowntable_row: (a: number, b: number, c: number) => void;
    readonly panTimelineBy: (a: number, b: number, c: number) => number;
    readonly parcelDecode: (a: number, b: number, c: number, d: number) => void;
    readonly parcelDecodeResultExport: (a: number, b: number, c: number) => void;
    readonly parcelDefaultLimits: () => number;
    readonly parcelEncode: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly parcelEncodeResultExport: (a: number, b: number) => void;
    readonly parcelInspect: (a: number, b: number, c: number, d: number) => void;
    readonly parcelResultExportPrefix: (a: number) => void;
    readonly parseImplementedSpecs: (a: number, b: number) => void;
    readonly parseJobMeta: (a: number, b: number, c: number) => void;
    readonly parseSimc: (a: number, b: number, c: number) => void;
    readonly parseSpellDesc: (a: number, b: number, c: number) => void;
    readonly renderGlobalString: (a: number, b: number, c: number) => void;
    readonly resolveItem: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly sha256Hex: (a: number, b: number, c: number) => void;
    readonly signMessage: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly tournamentPayload: (a: number, b: number) => void;
    readonly verifySignature: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly zoomTimelineAt: (a: number, b: number, c: number, d: number) => number;
    readonly __wbg_analyzeresult_free: (a: number, b: number) => void;
    readonly analyzeSpellDesc: (a: number, b: number, c: number) => number;
    readonly analyzeresult_dependencies: (a: number) => number;
    readonly analyzeresult_hasErrors: (a: number) => number;
    readonly analyzeresult_parseErrors: (a: number, b: number) => void;
    readonly renderSpellDescWithData: (a: number, b: number) => void;
    readonly tokenizeSpellDesc: (a: number, b: number, c: number) => void;
    readonly __wbindgen_export: (a: number, b: number) => number;
    readonly __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_export3: (a: number) => void;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_export4: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
